# Whatsup — Firebase, WebRTC & Build Setup Guide

## 1. Prerequisites
- Android Gradle Plugin & Kotlin project (`com.aistudio.whatsup.kpkzmr`, namespace `com.example`)
- Firebase project configured with `app/google-services.json` and `app/src/main/res/values/firebase_applet_config.xml`
- Named Firestore database ID: `ai-studio-android-whatsup-d57b1d05-3425-4498-ab4e-81ce5934b965`
- Firebase CLI (`npm install -g firebase-tools`) logged into your project (`firebase login`)

## 2. Enable Firebase Phone Authentication & Play Integrity
1. Open **Firebase Console → Authentication → Sign-in method**.
2. Enable **Phone** provider.
   - *(Optional)* Keep **Google** enabled if users will optionally link a Google account in **Settings → Backup & Account**.
3. Register your debug and release signing certificate **SHA-1** and **SHA-256** fingerprints under **Firebase Console → Project Settings → Your apps → Android (`com.aistudio.whatsup.kpkzmr`)**.
   ```bash
   keytool -list -v -keystore ~/.android/debug.keystore -alias androiddebugkey -storepass android -keypass android
   ```
4. Enable **Play Integrity API** (Google Cloud Console) and link **Firebase App Check → Play Integrity** so Phone Auth SMS verification runs silently without reCAPTCHA fallback on Play-certified devices.
5. For QA without consuming live SMS quota, add dedicated **Phone numbers for testing** inside Firebase Console → Authentication → Sign-in method → Phone (never hardcode OTPs in app code).

## 3. Deploy Firestore Rules, Composite Indexes & Storage Rules
The workspace includes `/firebase.json`, `/firestore.rules`, `/firestore.indexes.json`, and `/storage.rules`. Deploy them together:
```bash
firebase deploy --only firestore:rules,firestore:indexes,storage
```

### Key Indexes (`/firestore.indexes.json`)
- `conversations`: `participantUids` (CONTAINS) + `sortOrder` (DESCENDING)
- `statuses`: `allowedUids` (CONTAINS) + `createdAt` (DESCENDING)
- `calls`: `participantUids` (CONTAINS) + `createdAt` (DESCENDING)

## 4. Deploy Cloud Functions (`/functions`)
`/functions/index.js` implements:
- `setTwoStepPin`, `verifyTwoStepPin`, `disableTwoStepPin`, `recoverTwoStepPin` — Salted `scrypt` 6-digit PIN hashing, 5-attempt lockout for 15 minutes, zero plaintext storage.
- `onMessageCreatedNotify` — Sends FCM push notifications to offline/background recipients respecting conversation mute settings.
- `onCallCreatedNotify` — Sends high-priority FCM call alerts when a WebRTC call enters `RINGING`.
- `cleanupExpiredStatuses` — Scheduled hourly purge of expired 24-hour status documents & viewer subcollections.

Install dependencies and deploy (requires Firebase Blaze plan for Cloud Functions v2 & Cloud Scheduler):
```bash
cd functions
npm install
cd ..
firebase deploy --only functions
```

## 5. Configure WebRTC TURN Server (NAT Traversal for Calls)
By default, `WebRtcCallManager` uses `stun:stun.l.google.com:19302` and `stun:stun1.l.google.com:19302`.
For calls across carrier-grade NAT / symmetric firewalls:
1. Provision a coturn / metered.ca / Twilio TURN server.
2. Open **Whatsup → Settings → WebRTC TURN Server** in the app and enter your `turn:host:3478` URI, username, and credential.

## 6. Build & Test Locally
```bash
# Run unit & Robolectric tests (PhoneNumberUtils, WhatsupCryptoManager, LocalWhatsupStore, Rate Limits)
gradle :app:testDebugUnitTest

# Verify Firestore security rules against emulator
firebase emulators:exec --only firestore "node --test firestore.test.js"

# Build debug APK
gradle assembleDebug
```
