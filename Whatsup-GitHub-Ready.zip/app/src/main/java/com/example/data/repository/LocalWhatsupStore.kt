package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.model.ChatMessage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

private const val TAG = "LocalWhatsupStore"
private const val STORE_FILE_NAME = "whatsup_offline_outbox_v2.json"

/**
 * UID-scoped local cache and Offline Bluetooth Mesh outbox.
 * Persists offline / Bluetooth queued messages across app restarts so they
 * automatically sync to Firestore once internet connectivity returns.
 * Contains zero pre-populated dummy chats or fake contacts.
 */
class LocalWhatsupStore(context: Context) {

    private val storeFile = File(context.applicationContext.filesDir, STORE_FILE_NAME)
    private val mutex = Mutex()

    // Keyed by ownerUid -> (conversationId -> queued messages)
    private val outboxState = MutableStateFlow<Map<String, Map<String, List<ChatMessage>>>>(emptyMap())
    private var loaded = false

    private suspend fun ensureLoaded() {
        mutex.withLock { loadIfNeededLocked() }
    }

    fun observeQueuedMessages(uid: String, chatId: String): Flow<List<ChatMessage>> =
        kotlinx.coroutines.flow.flow {
            ensureLoaded()
            outboxState.map { all ->
                all[uid]?.get(chatId).orEmpty()
            }.collect { emit(it) }
        }

    fun observeAllPendingCount(uid: String): Flow<Int> =
        kotlinx.coroutines.flow.flow {
            ensureLoaded()
            outboxState.map { all ->
                all[uid]?.values?.sumOf { list ->
                    list.count { it.viaBluetooth && it.tickStatus == "PENDING_SYNC" }
                } ?: 0
            }.collect { emit(it) }
        }

    suspend fun getPendingOutboxForUser(uid: String): Map<String, List<ChatMessage>> {
        mutex.withLock {
            loadIfNeededLocked()
            return outboxState.value[uid].orEmpty()
        }
    }

    suspend fun enqueueOfflineMessage(uid: String, chatId: String, message: ChatMessage) {
        if (uid.isBlank() || chatId.isBlank()) return
        mutateLocked { current ->
            val userChats = current[uid].orEmpty().toMutableMap()
            val list = userChats[chatId].orEmpty()
            if (list.none { it.id == message.id }) {
                userChats[chatId] = list + message
            }
            current.toMutableMap().apply { put(uid, userChats) }
        }
    }

    suspend fun removeSyncedMessages(uid: String, chatId: String, syncedIds: Set<String>) {
        if (uid.isBlank() || syncedIds.isEmpty()) return
        mutateLocked { current ->
            val userChats = current[uid]?.toMutableMap() ?: return@mutateLocked current
            val remaining = userChats[chatId].orEmpty().filterNot { it.id in syncedIds }
            if (remaining.isEmpty()) {
                userChats.remove(chatId)
            } else {
                userChats[chatId] = remaining
            }
            current.toMutableMap().apply {
                if (userChats.isEmpty()) remove(uid) else put(uid, userChats)
            }
        }
    }

    suspend fun clearUserOutbox(uid: String) {
        mutateLocked { current ->
            current.toMutableMap().apply { remove(uid) }
        }
    }

    private suspend fun mutateLocked(
        transform: (Map<String, Map<String, List<ChatMessage>>>) -> Map<String, Map<String, List<ChatMessage>>>
    ) {
        mutex.withLock {
            loadIfNeededLocked()
            val next = transform(outboxState.value)
            outboxState.value = next
            saveLocked(next)
        }
    }

    private suspend fun loadIfNeededLocked() {
        if (loaded) return
        loaded = true
        if (!storeFile.exists()) return
        try {
            val raw = withContext(Dispatchers.IO) { storeFile.readText(Charsets.UTF_8) }
            if (raw.isBlank()) return
            val root = JSONObject(raw)
            val parsed = mutableMapOf<String, Map<String, List<ChatMessage>>>()
            root.keys().forEach { uid ->
                val convObj = root.optJSONObject(uid) ?: return@forEach
                val convMap = mutableMapOf<String, List<ChatMessage>>()
                convObj.keys().forEach { cid ->
                    val arr = convObj.optJSONArray(cid) ?: return@forEach
                    val msgs = (0 until arr.length()).map { i ->
                        val m = arr.getJSONObject(i)
                        ChatMessage(
                            id = m.optString("id"),
                            userId = m.optString("userId", uid),
                            chatId = m.optString("chatId", cid),
                            senderName = m.optString("senderName", "Me"),
                            senderPhone = m.optString("senderPhone", ""),
                            fromMe = true,
                            text = m.optString("text"),
                            messageType = m.optString("messageType", "TEXT"),
                            tickStatus = m.optString("tickStatus", "PENDING_SYNC"),
                            viaBluetooth = m.optBoolean("viaBluetooth", true),
                            replyToText = m.optString("replyToText").ifBlank { null },
                            replyToSender = m.optString("replyToSender").ifBlank { null },
                            mediaMeta = m.optString("mediaMeta").ifBlank { null },
                            scheduledForMillis = if (m.has("scheduledForMillis")) m.optLong("scheduledForMillis") else null,
                            timeLabel = m.optString("timeLabel", "now")
                        )
                    }
                    if (msgs.isNotEmpty()) convMap[cid] = msgs
                }
                if (convMap.isNotEmpty()) parsed[uid] = convMap
            }
            outboxState.value = parsed
        } catch (e: Exception) {
            Log.w(TAG, "Failed to load offline outbox cache: ${e.message}")
        }
    }

    private suspend fun saveLocked(state: Map<String, Map<String, List<ChatMessage>>>) {
        try {
            val root = JSONObject()
            state.forEach { (uid, convMap) ->
                val convObj = JSONObject()
                convMap.forEach { (cid, msgs) ->
                    val arr = JSONArray()
                    msgs.forEach { m ->
                        arr.put(JSONObject().apply {
                            put("id", m.id)
                            put("userId", m.userId)
                            put("chatId", m.chatId)
                            put("senderName", m.senderName)
                            put("senderPhone", m.senderPhone)
                            put("text", m.text)
                            put("messageType", m.messageType)
                            put("tickStatus", m.tickStatus)
                            put("viaBluetooth", m.viaBluetooth)
                            if (m.replyToText != null) put("replyToText", m.replyToText)
                            if (m.replyToSender != null) put("replyToSender", m.replyToSender)
                            if (m.mediaMeta != null) put("mediaMeta", m.mediaMeta)
                            if (m.scheduledForMillis != null) put("scheduledForMillis", m.scheduledForMillis)
                            put("timeLabel", m.timeLabel)
                        })
                    }
                    convObj.put(cid, arr)
                }
                root.put(uid, convObj)
            }
            withContext(Dispatchers.IO) {
                storeFile.writeText(root.toString(), Charsets.UTF_8)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to persist offline outbox cache: ${e.message}")
        }
    }
}
