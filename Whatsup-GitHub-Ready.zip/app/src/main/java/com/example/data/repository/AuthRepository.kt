package com.example.data.repository

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseNetworkException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthException
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.functions.FirebaseFunctionsException
import com.google.firebase.functions.functions
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

private const val TAG = "AuthRepository"

sealed interface PhoneVerificationEvent {
    data class CodeSent(
        val verificationId: String,
        val resendToken: PhoneAuthProvider.ForceResendingToken
    ) : PhoneVerificationEvent
    data class InstantVerified(val credential: PhoneAuthCredential) : PhoneVerificationEvent
    data class Failed(val userFriendlyMessage: String) : PhoneVerificationEvent
}

class AuthRepository(
    private val auth: FirebaseAuth = Firebase.auth,
    private val functions: FirebaseFunctions = Firebase.functions
) {
    fun observeAuthUser(): Flow<FirebaseUser?> = callbackFlow {
        val listener = FirebaseAuth.AuthStateListener { firebaseAuth ->
            trySend(firebaseAuth.currentUser)
        }
        auth.addAuthStateListener(listener)
        awaitClose { auth.removeAuthStateListener(listener) }
    }

    fun currentUser(): FirebaseUser? = auth.currentUser

    /**
     * Initiates real Firebase Phone Authentication SMS OTP delivery.
     */
    fun sendPhoneOtp(
        activity: Activity,
        phoneE164: String,
        resendToken: PhoneAuthProvider.ForceResendingToken? = null,
        onEvent: (PhoneVerificationEvent) -> Unit
    ) {
        val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
            override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                onEvent(PhoneVerificationEvent.InstantVerified(credential))
            }

            override fun onVerificationFailed(e: FirebaseException) {
                Log.w(TAG, "Phone verification failed: ${e.message}", e)
                onEvent(PhoneVerificationEvent.Failed(mapPhoneAuthError(e)))
            }

            override fun onCodeSent(
                verificationId: String,
                token: PhoneAuthProvider.ForceResendingToken
            ) {
                onEvent(PhoneVerificationEvent.CodeSent(verificationId, token))
            }
        }

        val builder = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phoneE164)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(callbacks)
        if (resendToken != null) {
            builder.setForceResendingToken(resendToken)
        }
        PhoneAuthProvider.verifyPhoneNumber(builder.build())
    }

    suspend fun signInWithPhoneCredential(credential: PhoneAuthCredential): Result<FirebaseUser> {
        return try {
            val result = auth.signInWithCredential(credential).await()
            val user = result.user ?: return Result.failure(IllegalStateException("Authentication returned no user."))
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapPhoneAuthError(e)))
        }
    }

    suspend fun verifyOtpCode(verificationId: String, otpCode: String): Result<FirebaseUser> {
        val credential = PhoneAuthProvider.getCredential(verificationId, otpCode)
        return signInWithPhoneCredential(credential)
    }

    suspend fun updateVerifiedPhoneNumber(
        verificationId: String,
        otpCode: String
    ): Result<String> {
        val user = auth.currentUser ?: return Result.failure(IllegalStateException("Sign in first."))
        return try {
            val credential = PhoneAuthProvider.getCredential(verificationId, otpCode)
            user.updatePhoneNumber(credential).await()
            user.reload().await()
            Result.success(user.phoneNumber.orEmpty())
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapPhoneAuthError(e)))
        }
    }

    suspend fun checkHasProfileAndTwoStep(
        db: FirebaseFirestore,
        uid: String
    ): Pair<Boolean, Boolean> {
        return try {
            val snap = db.collection("users").document(uid).get().await()
            if (!snap.exists()) {
                false to false
            } else {
                val twoStep = snap.getBoolean("twoStepEnabled") == true
                true to twoStep
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed checking user profile / 2FA status: ${e.message}")
            false to false
        }
    }

    suspend fun setTwoStepPinServerSide(
        pin: String,
        currentPin: String? = null,
        recoveryHint: String = ""
    ): Result<Unit> {
        return try {
            val payload = hashMapOf<String, Any>(
                "pin" to pin,
                "recoveryHint" to recoveryHint.trim()
            ).apply {
                if (!currentPin.isNullOrBlank()) put("currentPin", currentPin)
            }
            functions.getHttpsCallable("setTwoStepPin").call(payload).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapFunctionsError(e)))
        }
    }

    suspend fun verifyTwoStepPinServerSide(pin: String): Result<Boolean> {
        return try {
            val res = functions.getHttpsCallable("verifyTwoStepPin")
                .call(mapOf("pin" to pin))
                .await()
            @Suppress("UNCHECKED_CAST")
            val data = res.getData() as? Map<String, Any>
            val verified = data?.get("verified") as? Boolean ?: true
            Result.success(verified)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapFunctionsError(e)))
        }
    }

    suspend fun disableTwoStepPinServerSide(currentPin: String): Result<Unit> {
        return try {
            functions.getHttpsCallable("disableTwoStepPin")
                .call(mapOf("currentPin" to currentPin))
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapFunctionsError(e)))
        }
    }

    suspend fun recoverTwoStepPinServerSide(recoveryHint: String, newPin: String): Result<Unit> {
        return try {
            functions.getHttpsCallable("recoverTwoStepPin")
                .call(mapOf("recoveryHint" to recoveryHint, "newPin" to newPin))
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(mapFunctionsError(e)))
        }
    }

    /**
     * Optional Google Sign-In linking (or backup sign-in) without blocking primary phone registration.
     */
    suspend fun linkOrSignInWithGoogleOptional(activity: Activity): Result<FirebaseUser> {
        val clientId = try {
            activity.getString(R.string.default_web_client_id)
        } catch (_: Exception) {
            return Result.failure(IllegalStateException("Google OAuth web client ID is not configured."))
        }
        val credentialManager = CredentialManager.create(activity)
        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(signInOption)
            .build()
        return try {
            val cred = credentialManager.getCredential(activity, request).credential
            if (cred is CustomCredential && cred.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                val token = GoogleIdTokenCredential.createFrom(cred.data).idToken
                val googleCred = GoogleAuthProvider.getCredential(token, null)
                val existingUser = auth.currentUser
                val authResult = if (existingUser != null) {
                    existingUser.linkWithCredential(googleCred).await()
                } else {
                    auth.signInWithCredential(googleCred).await()
                }
                val user = authResult.user ?: return Result.failure(IllegalStateException("Google Sign-In returned no user."))
                Result.success(user)
            } else {
                Result.failure(IllegalStateException("Unsupported credential returned."))
            }
        } catch (e: GetCredentialCancellationException) {
            Log.w(TAG, "Optional Google link cancelled: ${e.message}")
            Result.failure(e)
        } catch (e: Exception) {
            Result.failure(IllegalStateException(e.localizedMessage ?: "Google linking failed."))
        }
    }

    suspend fun signOut(context: Context) {
        withContext(NonCancellable) {
            runCatching {
                CredentialManager.create(context).clearCredentialState(ClearCredentialStateRequest())
            }
            auth.signOut()
        }
    }

    private fun mapPhoneAuthError(e: Exception): String {
        return when (e) {
            is FirebaseAuthInvalidCredentialsException -> when (e.errorCode) {
                "ERROR_INVALID_PHONE_NUMBER" -> "Invalid mobile phone number. Check country code and digits."
                "ERROR_INVALID_VERIFICATION_CODE" -> "Incorrect OTP code. Please check the SMS and try again."
                "ERROR_SESSION_EXPIRED" -> "This OTP code has expired. Tap Resend OTP to get a new code."
                else -> e.localizedMessage ?: "Invalid verification code or phone number."
            }
            is FirebaseTooManyRequestsException ->
                "SMS quota or rate limit reached for this number. Please wait before requesting another code."
            is FirebaseNetworkException ->
                "Network connection lost. Check your internet and try again."
            is FirebaseAuthException -> when (e.errorCode) {
                "ERROR_CREDENTIAL_ALREADY_IN_USE" -> "This phone number is already linked to another Whatsup account."
                "ERROR_REQUIRES_RECENT_LOGIN" -> "Please re-verify your current session before changing your phone number."
                else -> e.localizedMessage ?: "Phone authentication error (${e.errorCode})."
            }
            else -> e.localizedMessage ?: "Phone verification failed."
        }
    }

    private fun mapFunctionsError(e: Exception): String {
        if (e is FirebaseFunctionsException) {
            return when (e.code) {
                FirebaseFunctionsException.Code.NOT_FOUND,
                FirebaseFunctionsException.Code.UNAVAILABLE ->
                    "Two-Step Verification Cloud Function is not deployed yet. Deploy /functions via Firebase CLI (see FIREBASE_SETUP.md)."
                else -> e.message ?: "Two-Step Verification server error."
            }
        }
        return e.localizedMessage ?: "Two-Step Verification request failed."
    }
}
