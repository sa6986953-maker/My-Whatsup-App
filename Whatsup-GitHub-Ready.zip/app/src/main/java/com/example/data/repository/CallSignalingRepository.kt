package com.example.data.repository

import com.example.core.OperationType
import com.example.core.handleFirestoreError
import com.example.data.model.CallRecord
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class RemoteIceCandidate(
    val id: String,
    val sdpMid: String,
    val sdpMLineIndex: Int,
    val sdp: String
)

class CallSignalingRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    private fun requireUid(): String = auth.currentUser?.uid
        ?: throw IllegalStateException("Authentication required for calling.")

    private fun callsCol() = db.collection("calls")

    fun observeCallHistory(uid: String): Flow<List<CallRecord>> =
        callsCol()
            .whereArrayContains("participantUids", uid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snap ->
                snap.documents.mapNotNull { doc -> mapCallDoc(doc, uid) }
            }
            .catch { error ->
                val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fe == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) handleFirestoreError(fe ?: error, OperationType.LIST, "calls")
                throw error
            }

    fun observeIncomingRingingCalls(uid: String): Flow<List<CallRecord>> =
        observeCallHistory(uid).map { calls ->
            calls.filter { it.status == "RINGING" && it.calleeUid == uid && it.callerUid != uid }
        }

    fun observeCallSession(callId: String, currentUid: String): Flow<CallRecord?> =
        callsCol().document(callId)
            .snapshots()
            .map { snap -> if (snap.exists()) mapCallDoc(snap, currentUid) else null }
            .catch { error ->
                val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fe == null && error is CancellationException) throw error
                throw error
            }

    fun observeRemoteIceCandidates(callId: String, listenForCallerCandidates: Boolean): Flow<RemoteIceCandidate> = callbackFlow {
        val sub = if (listenForCallerCandidates) "callerCandidates" else "calleeCandidates"
        val reg = callsCol().document(callId).collection(sub)
            .addSnapshotListener { snap, err ->
                if (err != null || snap == null) return@addSnapshotListener
                for (change in snap.documentChanges) {
                    if (change.type == DocumentChange.Type.ADDED) {
                        val d = change.document
                        val sdp = d.getString("sdp").orEmpty()
                        if (sdp.isNotBlank()) {
                            trySend(
                                RemoteIceCandidate(
                                    id = d.id,
                                    sdpMid = d.getString("sdpMid").orEmpty(),
                                    sdpMLineIndex = (d.getLong("sdpMLineIndex") ?: 0L).toInt(),
                                    sdp = sdp
                                )
                            )
                        }
                    }
                }
            }
        awaitClose { reg.remove() }
    }

    suspend fun createOutgoingCall(
        callerName: String,
        calleeUid: String,
        calleeName: String,
        callType: String,
        offerSdp: String? = null,
        participantUids: List<String>? = null,
        callLinkCode: String? = null,
        recorded: Boolean = false
    ): Result<String> {
        return try {
            val uid = requireUid()
            val callId = "call_${UUID.randomUUID().toString().replace("-", "").take(16)}"
            val members = (participantUids ?: listOf(uid, calleeUid)).distinct().take(32)
            val payload = hashMapOf<String, Any>(
                "callerUid" to uid,
                "callerName" to callerName.ifBlank { "Whatsup User" }.take(80),
                "calleeUid" to calleeUid.ifBlank { uid },
                "calleeName" to calleeName.ifBlank { "Whatsup Peer" }.take(80),
                "participantUids" to members,
                "callType" to callType,
                "status" to if (callLinkCode != null) "ENDED" else "RINGING",
                "durationSeconds" to 0L,
                "recorded" to recorded,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).apply {
                if (!offerSdp.isNullOrBlank()) put("offerSdp", offerSdp.take(20000))
                if (!callLinkCode.isNullOrBlank()) put("callLinkCode", callLinkCode.take(120))
            }
            callsCol().document(callId).set(payload).await()
            Result.success(callId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "calls")
            Result.failure(e)
        }
    }

    suspend fun updateOfferSdp(callId: String, offerSdp: String): Result<Unit> =
        updateCallFields(callId, mapOf("offerSdp" to offerSdp.take(20000)))

    suspend fun acceptCallWithAnswer(callId: String, answerSdp: String): Result<Unit> =
        updateCallFields(callId, mapOf("status" to "ACCEPTED", "answerSdp" to answerSdp.take(20000)))

    suspend fun updateCallStatus(
        callId: String,
        status: String,
        durationSeconds: Long = 0L,
        recorded: Boolean = false
    ): Result<Unit> = updateCallFields(
        callId,
        mapOf(
            "status" to status,
            "durationSeconds" to durationSeconds.coerceIn(0L, 86400L),
            "recorded" to recorded
        )
    )

    suspend fun addIceCandidate(
        callId: String,
        isCaller: Boolean,
        sdpMid: String,
        sdpMLineIndex: Int,
        sdp: String
    ): Result<Unit> {
        return try {
            requireUid()
            val sub = if (isCaller) "callerCandidates" else "calleeCandidates"
            callsCol().document(callId).collection(sub).add(
                mapOf(
                    "sdpMid" to sdpMid,
                    "sdpMLineIndex" to sdpMLineIndex.toLong(),
                    "sdp" to sdp,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private suspend fun updateCallFields(callId: String, updates: Map<String, Any>): Result<Unit> {
        return try {
            requireUid()
            val payload = updates.toMutableMap().apply { put("updatedAt", FieldValue.serverTimestamp()) }
            callsCol().document(callId).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "calls/$callId")
            Result.failure(e)
        }
    }

    private fun mapCallDoc(doc: DocumentSnapshot, currentUid: String): CallRecord? {
        val callerUid = doc.getString("callerUid") ?: return null
        val callerName = doc.getString("callerName").orEmpty()
        val calleeUid = doc.getString("calleeUid").orEmpty()
        val calleeName = doc.getString("calleeName").orEmpty()
        val status = doc.getString("status") ?: "ENDED"
        @Suppress("UNCHECKED_CAST")
        val participants = (doc.get("participantUids") as? List<String>).orEmpty()
        val isOutgoing = callerUid == currentUid
        val direction = when {
            isOutgoing -> "OUTGOING"
            status == "MISSED" || status == "REJECTED" -> "MISSED"
            else -> "INCOMING"
        }
        val durationSec = doc.getLong("durationSeconds") ?: 0L
        val durationLabel = when {
            doc.getString("callLinkCode") != null -> "Call Link Active"
            status == "RINGING" -> "Ringing..."
            status == "MISSED" -> "Missed"
            status == "REJECTED" -> "Declined"
            durationSec > 0L -> "%d:%02d".format(durationSec / 60, durationSec % 60)
            else -> "0:00"
        }
        val ts = doc.getTimestamp("createdAt")?.toDate()
        val timeLabel = if (ts != null) {
            SimpleDateFormat("MMM d, h:mm a", Locale.getDefault()).format(ts)
        } else {
            SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        }
        return CallRecord(
            id = doc.id,
            userId = currentUid,
            callerUid = callerUid,
            callerName = callerName,
            calleeUid = calleeUid,
            calleeName = calleeName,
            peerUid = if (isOutgoing) calleeUid else callerUid,
            peerName = if (isOutgoing) calleeName else callerName,
            callType = doc.getString("callType") ?: "VOICE",
            direction = direction,
            status = status,
            offerSdp = doc.getString("offerSdp"),
            answerSdp = doc.getString("answerSdp"),
            durationSeconds = durationSec,
            durationLabel = durationLabel,
            participantUids = participants,
            participantCount = participants.size.coerceAtLeast(1).toLong(),
            callLinkCode = doc.getString("callLinkCode"),
            recorded = doc.getBoolean("recorded") == true,
            timeLabel = timeLabel,
            createdAt = doc.getTimestamp("createdAt"),
            updatedAt = doc.getTimestamp("updatedAt")
        )
    }
}
