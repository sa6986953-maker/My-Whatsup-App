package com.example.data.repository

import android.util.Log
import com.example.data.model.ChatMessage
import com.google.firebase.Firebase
import com.google.firebase.ai.ai
import com.google.firebase.ai.type.Schema
import com.google.firebase.ai.type.generationConfig
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withTimeout
import org.json.JSONObject

private const val TAG = "WhatsupAiRepository"

class WhatsupAiRepository {

    private val model by lazy {
        Firebase.ai.generativeModel("gemini-3.8-flash")
    }

    private val suggestedRepliesSchema = Schema.obj(
        properties = mapOf(
            "replies" to Schema.array(
                items = Schema.string(description = "Short natural reply text (2 to 12 words)"),
                description = "Exactly 3 contextually relevant suggested replies"
            )
        )
    )

    private val suggestedRepliesModel by lazy {
        Firebase.ai.generativeModel(
            modelName = "gemini-3.8-flash",
            generationConfig = generationConfig {
                responseMimeType = "application/json"
                responseSchema = suggestedRepliesSchema
            }
        )
    }

    suspend fun generateSuggestedReplies(
        chatTitle: String,
        recentMessages: List<ChatMessage>
    ): List<String> {
        val visibleMessages = recentMessages
            .filter { !it.deletedForMe && !it.deletedForEveryone }
            .takeLast(12)

        val lastReceived = visibleMessages.lastOrNull { !it.fromMe }

        val transcript = if (visibleMessages.isEmpty()) {
            "(No previous messages yet — suggest friendly opening greetings.)"
        } else {
            visibleMessages.joinToString("\n") { msg ->
                val sender = if (msg.fromMe) "Me" else msg.senderName
                "$sender: ${msg.text}"
            }
        }

        val lastReceivedFocus = if (lastReceived != null) {
            "Last received message to reply to:\n${lastReceived.senderName}: ${lastReceived.text}"
        } else {
            "No incoming message yet — suggest natural follow-ups based on the latest message."
        }

        val prompt = """
            You are Whatsup AI inside a Pakistani messaging app.
            Analyze the last received message below within the context of the conversation with "$chatTitle", and generate exactly 3 distinct, natural, context-aware quick reply options for "Me".
            Match the language and cultural tone of the last received message (for example Roman Urdu, English, or mixed Roman Urdu + English as used in Pakistan).
            Keep each quick reply concise (2 to 12 words), directly responsive to the last received message, and immediately usable.

            $lastReceivedFocus

            Recent conversation context:
            $transcript
        """.trimIndent()

        return try {
            val response = withTimeout(60_000L) {
                suggestedRepliesModel.generateContent(prompt)
            }
            val jsonString = response.text
                ?: throw IllegalStateException("Whatsup AI returned an empty suggestions response.")
            val json = JSONObject(jsonString)
            val repliesArray = json.getJSONArray("replies")
            val parsed = (0 until repliesArray.length())
                .mapNotNull { idx -> repliesArray.optString(idx)?.trim() }
                .filter { it.isNotBlank() }
                .distinct()
                .take(3)
            if (parsed.isEmpty()) {
                throw IllegalStateException("Whatsup AI could not generate reply suggestions for this thread.")
            }
            parsed
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Suggested replies timed out", e)
            throw IllegalStateException("Suggested replies timed out after 60 seconds. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Suggested replies generation failed", e)
            throw e
        }
    }

    fun summarizeChatStream(chatTitle: String, messages: List<ChatMessage>): Flow<String> {
        val transcript = messages
            .filter { !it.deletedForMe && !it.deletedForEveryone }
            .takeLast(30)
            .joinToString("\n") { msg ->
                val sender = if (msg.fromMe) "Me" else msg.senderName
                "$sender: ${msg.text}"
            }
        val prompt = """
            You are Whatsup AI inside a messaging app popular in Pakistan.
            Summarize this conversation with "$chatTitle" into 3-5 clear, concise bullet points.
            If messages are in Roman Urdu, summarize clearly in clean English with key Roman Urdu terms preserved where helpful.
            Highlight any action items, times, or decisions.

            Conversation:
            $transcript
        """.trimIndent()
        return streamPrompt(prompt)
    }

    fun translateMessageStream(messageText: String, targetLanguage: String): Flow<String> {
        val prompt = """
            Translate the following chat message accurately into $targetLanguage.
            Keep the natural conversational tone. Output only the translation (and brief pronunciation note if Urdu script).

            Message:
            "$messageText"
        """.trimIndent()
        return streamPrompt(prompt)
    }

    fun draftReplyStream(
        chatTitle: String,
        recentMessages: List<ChatMessage>,
        tone: String
    ): Flow<String> {
        val transcript = recentMessages
            .filter { !it.deletedForMe && !it.deletedForEveryone }
            .takeLast(12)
            .joinToString("\n") { msg ->
                val sender = if (msg.fromMe) "Me" else msg.senderName
                "$sender: ${msg.text}"
            }
        val prompt = """
            You are Whatsup AI helping the user reply to "$chatTitle".
            Draft one natural, ready-to-send reply in $tone.
            Keep it concise (1-2 sentences) and culturally respectful for Pakistani messaging (if Roman Urdu is requested, write authentic Roman Urdu).
            Return ONLY the reply text without quotes.

            Recent conversation:
            $transcript
        """.trimIndent()
        return streamPrompt(prompt)
    }

    fun askAssistantStream(userQuestion: String, chatTitle: String, recentMessages: List<ChatMessage>): Flow<String> {
        val transcript = recentMessages.takeLast(15).joinToString("\n") {
            "${if (it.fromMe) "Me" else it.senderName}: ${it.text}"
        }
        val prompt = """
            You are Whatsup AI, a helpful built-in chat assistant.
            Context chat with "$chatTitle":
            $transcript

            User request: $userQuestion
        """.trimIndent()
        return streamPrompt(prompt)
    }

    private fun streamPrompt(prompt: String): Flow<String> = flow {
        val accumulated = StringBuilder()
        try {
            withTimeout(60_000L) {
                model.generateContentStream(prompt).collect { chunk ->
                    val piece = chunk.text.orEmpty()
                    if (piece.isNotEmpty()) {
                        accumulated.append(piece)
                        emit(accumulated.toString())
                    }
                }
            }
            if (accumulated.isBlank()) {
                throw IllegalStateException("Whatsup AI returned an empty response.")
            }
        } catch (e: TimeoutCancellationException) {
            Log.e(TAG, "Whatsup AI timed out", e)
            throw IllegalStateException("Whatsup AI timed out after 60 seconds. Please try again.")
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.e(TAG, "Whatsup AI inference failed", e)
            throw e
        }
    }
}
