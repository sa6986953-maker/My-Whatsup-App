package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.R
import com.example.core.OperationType
import com.example.core.PhoneNumberUtils
import com.example.core.StorageMediaManager
import com.example.core.crypto.WhatsupCryptoManager
import com.example.core.handleFirestoreError
import com.example.data.model.BlockedUser
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.MessageReactionHelper
import com.example.data.model.PrivacyAudience
import com.example.data.model.StatusUpdate
import com.example.data.model.StatusViewer
import com.example.data.model.UserProfile
import com.example.data.model.VerifiedContact
import com.google.firebase.Firebase
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

class WhatsupRepository(
    private val db: FirebaseFirestore,
    private val cryptoManager: WhatsupCryptoManager,
    private val storageMediaManager: StorageMediaManager,
    private val localOutbox: LocalWhatsupStore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    companion object {
        fun directConversationId(uidA: String, uidB: String): String {
            val ordered = listOf(uidA.trim(), uidB.trim()).sorted()
            return "direct_${ordered[0]}_${ordered[1]}"
        }
    }

    private fun requireUserId(): String = auth.currentUser?.uid
        ?: throw IllegalStateException("Phone verification required before accessing Whatsup Cloud.")

    private fun userDoc(uid: String) = db.collection("users").document(uid)
    private fun phoneDirDoc(hash: String) = db.collection("phoneDirectory").document(hash)
    private fun contactsCol(uid: String) = userDoc(uid).collection("contacts")
    private fun blockedCol(uid: String) = userDoc(uid).collection("blocked")
    private fun convsCol() = db.collection("conversations")
    private fun messagesCol(convId: String) = convsCol().document(convId).collection("messages")
    private fun statusesCol() = db.collection("statuses")
    private fun inviteDoc(code: String) = db.collection("inviteLinks").document(code)

    fun observeUserProfile(uid: String): Flow<UserProfile?> =
        userDoc(uid).snapshots()
            .map { snap -> snap.toObject(UserProfile::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fe == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) handleFirestoreError(fe ?: error, OperationType.GET, "users/$uid")
                throw error
            }

    fun observeVerifiedContacts(uid: String): Flow<List<VerifiedContact>> =
        contactsCol(uid).orderBy("savedName", Query.Direction.ASCENDING).snapshots()
            .map { snap -> snap.toObjects(VerifiedContact::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fe == null && error is CancellationException) throw error
                throw error
            }

    fun observeBlockedUsers(uid: String): Flow<List<BlockedUser>> =
        blockedCol(uid).snapshots()
            .map { snap -> snap.toObjects(BlockedUser::class.java, DocumentSnapshot.ServerTimestampBehavior.ESTIMATE) }
            .catch { error ->
                val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fe == null && error is CancellationException) throw error
                throw error
            }

    fun observeChats(uid: String): Flow<List<ChatThread>> =
        combine(
            convsCol()
                .whereArrayContains("participantUids", uid)
                .orderBy("sortOrder", Query.Direction.DESCENDING)
                .snapshots(),
            observeVerifiedContacts(uid)
        ) { snap, contacts ->
            val contactsByUid = contacts.associateBy { it.contactUid }
            val myPubKey = cryptoManager.getPublicKeyBase64(uid)
            snap.documents.mapNotNull { doc ->
                mapConversationDoc(doc, uid, myPubKey, contactsByUid)
            }
        }.catch { error ->
            val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
            if (fe == null && error is CancellationException) throw error
            if (auth.currentUser?.uid == uid) handleFirestoreError(fe ?: error, OperationType.LIST, "conversations")
            throw error
        }

    fun observeMessages(uid: String, thread: ChatThread): Flow<List<ChatMessage>> =
        combine(
            messagesCol(thread.id)
                .orderBy("createdAt", Query.Direction.ASCENDING)
                .snapshots(),
            localOutbox.observeQueuedMessages(uid, thread.id)
        ) { snap, queuedOffline ->
            val convKey = deriveConversationAesKey(uid, thread)
            val nowMs = System.currentTimeMillis()
            val cloudMessages = snap.documents.mapNotNull { doc ->
                mapMessageDoc(doc, uid, thread.id, convKey)
            }.filter { msg ->
                val exp = msg.expiresAtMillis
                exp == null || exp > nowMs
            }
            cloudMessages + queuedOffline
        }.catch { error ->
            val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
            if (fe == null && error is CancellationException) throw error
            if (auth.currentUser?.uid == uid) handleFirestoreError(fe ?: error, OperationType.LIST, "conversations/${thread.id}/messages")
            throw error
        }

    fun observePendingOutboxCount(uid: String): Flow<Int> = localOutbox.observeAllPendingCount(uid)

    suspend fun getMessagesSnapshot(thread: ChatThread): Result<List<ChatMessage>> {
        return try {
            val uid = requireUserId()
            val snap = messagesCol(thread.id).orderBy("createdAt", Query.Direction.ASCENDING).get().await()
            val convKey = deriveConversationAesKey(uid, thread)
            val nowMs = System.currentTimeMillis()
            val list = snap.documents.mapNotNull { mapMessageDoc(it, uid, thread.id, convKey) }
                .filter { it.expiresAtMillis == null || it.expiresAtMillis > nowMs }
            val queued = localOutbox.getPendingOutboxForUser(uid)[thread.id].orEmpty()
            Result.success(list + queued)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun observeStatuses(uid: String): Flow<List<StatusUpdate>> =
        statusesCol()
            .whereArrayContains("allowedUids", uid)
            .orderBy("createdAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snap ->
                val now = Timestamp.now()
                snap.documents.mapNotNull { doc -> mapStatusDoc(doc, uid, now) }
            }
            .catch { error ->
                val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fe == null && error is CancellationException) throw error
                if (auth.currentUser?.uid == uid) handleFirestoreError(fe ?: error, OperationType.LIST, "statuses")
                throw error
            }

    fun observeStatusViewers(statusId: String): Flow<List<StatusViewer>> =
        statusesCol().document(statusId).collection("viewers")
            .orderBy("viewedAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snap ->
                snap.documents.map { d ->
                    StatusViewer(
                        viewerUid = d.getString("viewerUid") ?: d.id,
                        viewerName = d.getString("viewerName") ?: "Whatsup User",
                        viewedAtMillis = d.getTimestamp("viewedAt")?.toDate()?.time ?: 0L
                    )
                }
            }
            .catch { error ->
                val fe = generateSequence(error) { it.cause }.filterIsInstance<FirebaseFirestoreException>().firstOrNull()
                if (fe == null && error is CancellationException) throw error
                emit(emptyList())
            }

    suspend fun registerOrUpdateUserProfile(
        displayName: String,
        phoneE164: String,
        about: String
    ): Result<Unit> {
        return try {
            val uid = requireUserId()
            val cleanPhone = phoneE164.ifBlank { auth.currentUser?.phoneNumber.orEmpty() }
            if (cleanPhone.isBlank()) {
                return Result.failure(IllegalStateException("A verified phone number is required."))
            }
            val phoneHash = PhoneNumberUtils.hashPhoneE164(cleanPhone)
            val pubKey = cryptoManager.getPublicKeyBase64(uid)
            val fcmToken = runCatching { FirebaseMessaging.getInstance().token.await() }.getOrNull()

            val existing = userDoc(uid).get().await()
            val batch = db.batch()
            if (!existing.exists()) {
                val userPayload = hashMapOf<String, Any>(
                    "userId" to uid,
                    "displayName" to displayName.trim().take(80),
                    "phoneE164" to cleanPhone,
                    "phoneHash" to phoneHash,
                    "about" to about.trim().take(200),
                    "identityPublicKey" to pubKey,
                    "twoStepEnabled" to false,
                    "online" to true,
                    "lastSeenAt" to System.currentTimeMillis(),
                    "lastSeenPrivacy" to PrivacyAudience.EVERYONE.value,
                    "onlinePrivacy" to PrivacyAudience.EVERYONE.value,
                    "photoPrivacy" to PrivacyAudience.EVERYONE.value,
                    "aboutPrivacy" to PrivacyAudience.EVERYONE.value,
                    "hideBlueTicks" to false,
                    "dataSaver" to false,
                    "appLockEnabled" to false,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).apply {
                    if (!fcmToken.isNullOrBlank()) put("fcmToken", fcmToken)
                }
                batch.set(userDoc(uid), userPayload)
            } else {
                val updates = hashMapOf<String, Any>(
                    "displayName" to displayName.trim().take(80),
                    "phoneE164" to cleanPhone,
                    "phoneHash" to phoneHash,
                    "identityPublicKey" to pubKey,
                    "online" to true,
                    "lastSeenAt" to System.currentTimeMillis(),
                    "updatedAt" to FieldValue.serverTimestamp()
                ).apply {
                    if (!fcmToken.isNullOrBlank()) put("fcmToken", fcmToken)
                }
                batch.update(userDoc(uid), updates)
            }

            batch.set(
                phoneDirDoc(phoneHash),
                mapOf(
                    "uid" to uid,
                    "phoneHash" to phoneHash,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "users")
            Result.failure(e)
        }
    }

    suspend fun syncFcmAndPresence(online: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        runCatching {
            val fcmToken = if (online) runCatching { FirebaseMessaging.getInstance().token.await() }.getOrNull() else null
            val updates = hashMapOf<String, Any>(
                "online" to online,
                "lastSeenAt" to System.currentTimeMillis(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).apply {
                if (!fcmToken.isNullOrBlank()) put("fcmToken", fcmToken)
            }
            userDoc(uid).update(updates).await()
        }
    }

    suspend fun changeRegisteredPhoneNumber(oldPhoneE164: String, newPhoneE164: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            val oldHash = if (oldPhoneE164.isNotBlank()) PhoneNumberUtils.hashPhoneE164(oldPhoneE164) else null
            val newHash = PhoneNumberUtils.hashPhoneE164(newPhoneE164)
            val batch = db.batch()
            if (oldHash != null && oldHash != newHash) {
                batch.delete(phoneDirDoc(oldHash))
            }
            batch.update(
                userDoc(uid),
                mapOf(
                    "phoneE164" to newPhoneE164,
                    "phoneHash" to newHash,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.set(
                phoneDirDoc(newHash),
                mapOf(
                    "uid" to uid,
                    "phoneHash" to newHash,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun lookupRegisteredUserByPhone(
        rawPhoneInput: String,
        defaultRegionIso: String = "PK",
        dialCodePrefix: String = "+92"
    ): Result<VerifiedContact> {
        return try {
            val myUid = requireUserId()
            val normalized = PhoneNumberUtils.normalizeToE164(rawPhoneInput, defaultRegionIso, dialCodePrefix)
                ?: return Result.failure(IllegalArgumentException("Please enter a valid mobile number."))
            val hash = PhoneNumberUtils.hashPhoneE164(normalized)
            val dirSnap = phoneDirDoc(hash).get().await()
            if (!dirSnap.exists()) {
                return Result.failure(IllegalStateException("This number is not on Whatsup."))
            }
            val targetUid = dirSnap.getString("uid").orEmpty()
            if (targetUid.isBlank()) {
                return Result.failure(IllegalStateException("This number is not on Whatsup."))
            }
            if (targetUid == myUid) {
                return Result.failure(IllegalArgumentException("That is your own registered Whatsup number."))
            }
            val userSnap = userDoc(targetUid).get().await()
            if (!userSnap.exists()) {
                return Result.failure(IllegalStateException("This number is not on Whatsup."))
            }
            val displayName = userSnap.getString("displayName")?.takeIf { it.isNotBlank() }
                ?: PhoneNumberUtils.formatDisplay(normalized)
            val photoPrivacy = userSnap.getString("photoPrivacy") ?: PrivacyAudience.EVERYONE.value
            val aboutPrivacy = userSnap.getString("aboutPrivacy") ?: PrivacyAudience.EVERYONE.value

            val contact = VerifiedContact(
                id = targetUid,
                contactUid = targetUid,
                savedName = displayName,
                phoneE164 = normalized,
                phoneHash = hash,
                photoUrl = if (photoPrivacy == PrivacyAudience.NOBODY.value) "" else userSnap.getString("photoUrl").orEmpty(),
                about = if (aboutPrivacy == PrivacyAudience.NOBODY.value) "" else userSnap.getString("about").orEmpty(),
                identityPublicKey = userSnap.getString("identityPublicKey").orEmpty(),
                online = userSnap.getBoolean("online") == true,
                lastSeenAt = userSnap.getLong("lastSeenAt") ?: 0L
            )
            // Persist into owner's contacts subcollection
            contactsCol(myUid).document(targetUid).set(
                mapOf(
                    "contactUid" to targetUid,
                    "savedName" to contact.savedName,
                    "phoneE164" to normalized,
                    "phoneHash" to hash,
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(contact)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.GET, "phoneDirectory")
            Result.failure(e)
        }
    }

    suspend fun openOrCreateDirectConversation(peer: VerifiedContact, myName: String): Result<String> {
        return try {
            val myUid = requireUserId()
            val blocked = blockedCol(myUid).document(peer.contactUid).get().await()
            if (blocked.exists()) {
                return Result.failure(IllegalStateException("You blocked ${peer.savedName}. Unblock in Privacy Settings to message."))
            }
            val convId = directConversationId(myUid, peer.contactUid)
            val ref = convsCol().document(convId)
            val snap = ref.get().await()
            if (!snap.exists()) {
                val payload = mapOf(
                    "type" to "DIRECT",
                    "participantUids" to listOf(myUid, peer.contactUid).sorted(),
                    "adminUids" to listOf(myUid, peer.contactUid).sorted(),
                    "createdByUid" to myUid,
                    "title" to peer.savedName.ifBlank { peer.phoneE164 }.take(120),
                    "onlyAdminCanSend" to false,
                    "bluetoothChat" to false,
                    "disappearingMode" to "OFF",
                    "lastMessagePreview" to "End-to-end encrypted chat ready",
                    "lastMessageSenderUid" to myUid,
                    "lastMessageTimeLabel" to SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date()),
                    "lastMessageTick" to "SENT",
                    "unreadCounts" to mapOf(myUid to 0L, peer.contactUid to 0L),
                    "sortOrder" to System.currentTimeMillis(),
                    "createdAt" to FieldValue.serverTimestamp(),
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                ref.set(payload).await()
            }
            Result.success(convId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.WRITE, "conversations")
            Result.failure(e)
        }
    }

    suspend fun createGroupConversation(
        title: String,
        description: String,
        chatType: String,
        members: List<VerifiedContact>,
        onlyAdminCanSend: Boolean,
        bluetoothChat: Boolean,
        communityName: String? = null
    ): Result<String> {
        return try {
            val myUid = requireUserId()
            val groupId = "grp_${UUID.randomUUID().toString().replace("-", "").take(14)}"
            val memberUids = (listOf(myUid) + members.map { it.contactUid }).distinct()
            val groupKey = WhatsupCryptoManager.generateRandomAesKeyBytes()
            val wrappedKeys = mutableMapOf<String, String>()
            val myPub = cryptoManager.getPublicKeyBase64(myUid)
            wrappedKeys[myUid] = cryptoManager.wrapGroupKeyForMember(myUid, myPub, groupKey, groupId)
            members.forEach { member ->
                if (member.identityPublicKey.isNotBlank()) {
                    wrappedKeys[member.contactUid] = cryptoManager.wrapGroupKeyForMember(
                        myUid = myUid,
                        memberPublicKeyBase64 = member.identityPublicKey,
                        groupAesKey = groupKey,
                        conversationId = groupId
                    )
                }
            }
            val inviteCode = UUID.randomUUID().toString().replace("-", "").take(10).uppercase(Locale.US)
            val unreadMap = memberUids.associateWith { 0L }
            val timeLabel = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

            val batch = db.batch()
            val convPayload = hashMapOf<String, Any>(
                "type" to chatType,
                "participantUids" to memberUids,
                "adminUids" to listOf(myUid),
                "createdByUid" to myUid,
                "title" to title.trim().take(120),
                "groupDescription" to description.trim().take(400),
                "inviteCode" to inviteCode,
                "onlyAdminCanSend" to onlyAdminCanSend,
                "bluetoothChat" to bluetoothChat,
                "disappearingMode" to "OFF",
                "lastMessagePreview" to if (bluetoothChat) "Bluetooth Mesh Group created" else "Group created",
                "lastMessageSenderUid" to myUid,
                "lastMessageTimeLabel" to timeLabel,
                "lastMessageTick" to if (bluetoothChat) "BLUETOOTH" else "SENT",
                "unreadCounts" to unreadMap,
                "wrappedGroupKeys" to wrappedKeys,
                "sortOrder" to System.currentTimeMillis(),
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).apply {
                if (!communityName.isNullOrBlank()) put("communityName", communityName.trim().take(100))
            }
            batch.set(convsCol().document(groupId), convPayload)
            batch.set(
                inviteDoc(inviteCode),
                mapOf(
                    "conversationId" to groupId,
                    "title" to title.trim().take(120),
                    "createdByUid" to myUid,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            )
            batch.commit().await()
            Result.success(groupId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "conversations")
            Result.failure(e)
        }
    }

    suspend fun joinGroupByInviteCode(rawCode: String): Result<String> {
        return try {
            val myUid = requireUserId()
            val cleanCode = rawCode.trim().substringAfterLast("/").uppercase(Locale.US)
            if (cleanCode.length < 6) return Result.failure(IllegalArgumentException("Invalid invite link or code."))
            val linkSnap = inviteDoc(cleanCode).get().await()
            if (!linkSnap.exists()) return Result.failure(IllegalStateException("Invite link expired or does not exist."))
            val convId = linkSnap.getString("conversationId").orEmpty()
            val convRef = convsCol().document(convId)
            val convSnap = convRef.get().await()
            @Suppress("UNCHECKED_CAST")
            val currentMembers = (convSnap.get("participantUids") as? List<String>).orEmpty()
            if (myUid in currentMembers) return Result.success(convId)

            @Suppress("UNCHECKED_CAST")
            val unread = ((convSnap.get("unreadCounts") as? Map<String, Any>) ?: emptyMap()).toMutableMap()
            unread[myUid] = 0L
            convRef.update(
                mapOf(
                    "participantUids" to (currentMembers + myUid).distinct(),
                    "unreadCounts" to unread,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(convId)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "inviteLinks")
            Result.failure(e)
        }
    }

    suspend fun updateGroupManagement(
        groupId: String,
        title: String? = null,
        description: String? = null,
        onlyAdminCanSend: Boolean? = null,
        participantUids: List<String>? = null,
        adminUids: List<String>? = null,
        groupPhotoUrl: String? = null
    ): Result<Unit> {
        return try {
            requireUserId()
            val updates = hashMapOf<String, Any>("updatedAt" to FieldValue.serverTimestamp())
            if (title != null) updates["title"] = title.trim().take(120)
            if (description != null) updates["groupDescription"] = description.trim().take(400)
            if (onlyAdminCanSend != null) updates["onlyAdminCanSend"] = onlyAdminCanSend
            if (participantUids != null) updates["participantUids"] = participantUids.distinct()
            if (adminUids != null) updates["adminUids"] = adminUids.distinct()
            if (groupPhotoUrl != null) updates["groupPhotoUrl"] = groupPhotoUrl
            convsCol().document(groupId).update(updates).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "conversations/$groupId")
            Result.failure(e)
        }
    }

    suspend fun uploadEncryptedUriAttachment(
        thread: ChatThread,
        senderName: String,
        senderPhone: String,
        uri: Uri,
        messageType: String,
        caption: String,
        viewOnce: Boolean
    ): Result<Unit> {
        val uploaded = storageMediaManager.uploadEncryptedUriMedia(thread.id, uri)
            .getOrElse { return Result.failure(it) }
        val sizeKb = (uploaded.byteSize / 1024L).coerceAtLeast(1L)
        val meta = "${uploaded.fileName} • ${sizeKb}KB"
        return sendMessage(
            thread = thread,
            senderName = senderName,
            senderPhone = senderPhone,
            text = caption.ifBlank { uploaded.fileName },
            messageType = if (viewOnce) "VIEW_ONCE" else messageType,
            viaBluetooth = false,
            mediaStoragePath = uploaded.storagePath,
            mediaKeyBase64 = uploaded.fileKeyBase64,
            mediaMeta = meta
        )
    }

    suspend fun uploadEncryptedVoiceAttachment(
        thread: ChatThread,
        senderName: String,
        senderPhone: String,
        audioFile: File,
        durationSeconds: Int
    ): Result<Unit> {
        val uploaded = storageMediaManager.uploadEncryptedFile(thread.id, audioFile, "audio/mp4")
            .getOrElse { return Result.failure(it) }
        val durLabel = "%d:%02d".format(durationSeconds / 60, durationSeconds % 60)
        return sendMessage(
            thread = thread,
            senderName = senderName,
            senderPhone = senderPhone,
            text = "Voice message ($durLabel)",
            messageType = "VOICE",
            viaBluetooth = false,
            mediaStoragePath = uploaded.storagePath,
            mediaKeyBase64 = uploaded.fileKeyBase64,
            mediaMeta = "${uploaded.fileName} • $durLabel"
        )
    }

    suspend fun downloadDecryptedMedia(message: ChatMessage): Result<File> {
        val path = message.mediaStoragePath
            ?: return Result.failure(IllegalStateException("No cloud media attachment on this message."))
        val key = message.mediaKeyBase64
            ?: return Result.failure(IllegalStateException("Missing media decryption key."))
        val fallbackName = message.mediaMeta?.substringBefore(" •")?.trim()?.ifBlank { "media.bin" } ?: "media.bin"
        return storageMediaManager.downloadAndDecryptMedia(path, key, fallbackName)
    }

    suspend fun sendMessage(
        thread: ChatThread,
        senderName: String,
        senderPhone: String,
        text: String,
        messageType: String = "TEXT",
        viaBluetooth: Boolean = false,
        replyToText: String? = null,
        replyToSender: String? = null,
        mediaStoragePath: String? = null,
        mediaKeyBase64: String? = null,
        mediaMeta: String? = null,
        scheduledForMillis: Long? = null
    ): Result<Unit> {
        val cleanText = text.trim().take(4000)
        if (cleanText.isEmpty()) return Result.failure(IllegalArgumentException("Message cannot be empty"))
        val uid = requireUserId()
        if (thread.onlyAdminCanSend && uid !in thread.adminUids) {
            return Result.failure(IllegalStateException("Only group admins can send messages in this group."))
        }
        if (thread.chatType == "DIRECT" && thread.peerUid.isNotBlank()) {
            val isBlocked = runCatching { blockedCol(uid).document(thread.peerUid).get().await().exists() }.getOrDefault(false)
            if (isBlocked) {
                return Result.failure(IllegalStateException("Unblock ${thread.title} to send messages."))
            }
        }

        val timeLabel = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())
        val msgId = "msg_${UUID.randomUUID().toString().replace("-", "").take(16)}"

        if (viaBluetooth) {
            val offlineMsg = ChatMessage(
                id = msgId,
                userId = uid,
                chatId = thread.id,
                senderName = senderName.ifBlank { "Me" },
                senderPhone = senderPhone,
                fromMe = true,
                text = cleanText,
                messageType = messageType,
                tickStatus = "PENDING_SYNC",
                viaBluetooth = true,
                replyToText = replyToText?.take(500),
                replyToSender = replyToSender?.take(80),
                mediaMeta = mediaMeta?.take(500),
                scheduledForMillis = scheduledForMillis,
                timeLabel = timeLabel
            )
            localOutbox.enqueueOfflineMessage(uid, thread.id, offlineMsg)
            return Result.success(Unit)
        }

        return try {
            val convKey = deriveConversationAesKey(uid, thread)
            val encrypted = convKey?.let {
                cryptoManager.encryptMessageText(cleanText, it, "msg:${thread.id}:$msgId")
            }
            val previewEncrypted = convKey?.let {
                cryptoManager.encryptMessageText(cleanText.take(180), it, "preview:${thread.id}")
            }
            val expiresAtMillis = when (thread.disappearingMode) {
                "24H" -> System.currentTimeMillis() + 24L * 3600L * 1000L
                "7D" -> System.currentTimeMillis() + 7L * 24L * 3600L * 1000L
                "90D" -> System.currentTimeMillis() + 90L * 24L * 3600L * 1000L
                else -> null
            }

            val msgPayload = hashMapOf<String, Any>(
                "senderUid" to uid,
                "senderName" to senderName.ifBlank { "Whatsup User" }.take(80),
                "senderPhone" to senderPhone.take(24),
                "text" to if (encrypted != null) "" else cleanText,
                "messageType" to messageType,
                "tickStatus" to "SENT",
                "viaBluetooth" to false,
                "edited" to false,
                "deletedForEveryone" to false,
                "deliveredTo" to mapOf(uid to true),
                "readBy" to mapOf(uid to true),
                "timeLabel" to timeLabel,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).apply {
                if (encrypted != null) {
                    put("ciphertext", encrypted.ciphertextBase64)
                    put("iv", encrypted.ivBase64)
                }
                if (!replyToText.isNullOrBlank()) put("replyToText", replyToText.take(500))
                if (!replyToSender.isNullOrBlank()) put("replyToSender", replyToSender.take(80))
                if (!mediaStoragePath.isNullOrBlank()) put("mediaStoragePath", mediaStoragePath)
                if (!mediaKeyBase64.isNullOrBlank()) put("mediaKeyBase64", mediaKeyBase64)
                if (!mediaMeta.isNullOrBlank()) put("mediaMeta", mediaMeta.take(500))
                if (expiresAtMillis != null) put("expiresAtMillis", expiresAtMillis)
                if (scheduledForMillis != null) put("scheduledForMillis", scheduledForMillis)
            }

            val convSnap = convsCol().document(thread.id).get().await()
            @Suppress("UNCHECKED_CAST")
            val unreadMap = ((convSnap.get("unreadCounts") as? Map<String, Any>) ?: emptyMap())
                .mapValues { (k, v) ->
                    if (k == uid) 0L else ((v as? Number)?.toLong() ?: 0L) + 1L
                }.toMutableMap().apply {
                    thread.participantUids.forEach { pUid ->
                        if (pUid != uid && !containsKey(pUid)) put(pUid, 1L)
                    }
                    put(uid, 0L)
                }

            val convUpdates = hashMapOf<String, Any>(
                "lastMessagePreview" to if (previewEncrypted != null) "🔒 Encrypted message" else cleanText.take(180),
                "lastMessageSenderUid" to uid,
                "lastMessageTimeLabel" to timeLabel,
                "lastMessageTick" to "SENT",
                "unreadCounts" to unreadMap,
                "sortOrder" to System.currentTimeMillis(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).apply {
                if (previewEncrypted != null) {
                    put("lastMessageCiphertext", previewEncrypted.ciphertextBase64)
                    put("lastMessageIv", previewEncrypted.ivBase64)
                }
            }

            val batch = db.batch()
            batch.set(messagesCol(thread.id).document(msgId), msgPayload)
            batch.update(convsCol().document(thread.id), convUpdates)
            batch.commit().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "conversations/${thread.id}/messages")
            Result.failure(e)
        }
    }

    suspend fun syncPendingBluetoothOutbox(threads: List<ChatThread>, senderName: String, senderPhone: String): Result<Int> {
        val uid = auth.currentUser?.uid ?: return Result.success(0)
        val outbox = localOutbox.getPendingOutboxForUser(uid)
        if (outbox.isEmpty()) return Result.success(0)
        val threadsById = threads.associateBy { it.id }
        var syncedCount = 0
        outbox.forEach { (convId, msgs) ->
            val thread = threadsById[convId] ?: return@forEach
            val syncedIds = mutableSetOf<String>()
            msgs.forEach { msg ->
                sendMessage(
                    thread = thread,
                    senderName = senderName,
                    senderPhone = senderPhone,
                    text = msg.text,
                    messageType = msg.messageType,
                    viaBluetooth = false,
                    replyToText = msg.replyToText,
                    replyToSender = msg.replyToSender,
                    mediaMeta = msg.mediaMeta,
                    scheduledForMillis = msg.scheduledForMillis
                ).onSuccess {
                    syncedIds.add(msg.id)
                    syncedCount++
                }
            }
            if (syncedIds.isNotEmpty()) {
                localOutbox.removeSyncedMessages(uid, convId, syncedIds)
            }
        }
        return Result.success(syncedCount)
    }

    suspend fun markMessagesDeliveredAndRead(
        thread: ChatThread,
        messages: List<ChatMessage>,
        isViewingThread: Boolean,
        hideBlueTicks: Boolean
    ) {
        val myUid = auth.currentUser?.uid ?: return
        val incoming = messages.filter { !it.fromMe && !it.viaBluetooth }
        if (incoming.isEmpty()) return

        val batch = db.batch()
        var ops = 0
        incoming.forEach { msg ->
            if (msg.tickStatus == "SENT") {
                val updates = mutableMapOf<String, Any>(
                    "deliveredTo.$myUid" to true,
                    "tickStatus" to if (isViewingThread && !hideBlueTicks) "READ" else "DELIVERED",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
                if (isViewingThread && !hideBlueTicks) updates["readBy.$myUid"] = true
                batch.update(messagesCol(thread.id).document(msg.id), updates)
                ops++
            } else if (isViewingThread && !hideBlueTicks && msg.tickStatus == "DELIVERED") {
                batch.update(
                    messagesCol(thread.id).document(msg.id),
                    mapOf(
                        "readBy.$myUid" to true,
                        "tickStatus" to "READ",
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                ops++
            }
        }
        if (isViewingThread) {
            batch.update(
                convsCol().document(thread.id),
                mapOf(
                    "unreadCounts.$myUid" to 0L,
                    "lastMessageTick" to if (hideBlueTicks) "DELIVERED" else "READ",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            )
            ops++
        }
        if (ops > 0) {
            runCatching { batch.commit().await() }
        }
    }

    suspend fun setTypingStatus(conversationId: String, typing: Boolean) {
        val uid = auth.currentUser?.uid ?: return
        runCatching {
            convsCol().document(conversationId).update(
                mapOf(
                    "typingUids.$uid" to typing,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
        }
    }

    suspend fun updatePerUserConversationPref(
        conversationId: String,
        fieldPrefix: String,
        value: Any
    ): Result<Unit> {
        return try {
            val uid = requireUserId()
            convsCol().document(conversationId).update(
                mapOf(
                    "$fieldPrefix.$uid" to value,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun setDisappearingMode(conversationId: String, mode: String): Result<Unit> {
        return try {
            requireUserId()
            convsCol().document(conversationId).update(
                mapOf("disappearingMode" to mode, "updatedAt" to FieldValue.serverTimestamp())
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun editMessage(thread: ChatThread, message: ChatMessage, newText: String): Result<Unit> {
        val clean = newText.trim().take(4000)
        if (clean.isEmpty()) return Result.failure(IllegalArgumentException("Message cannot be empty."))
        return try {
            val uid = requireUserId()
            if (message.userId != uid) return Result.failure(IllegalStateException("Only the sender can edit a message."))
            val convKey = deriveConversationAesKey(uid, thread)
            val encrypted = convKey?.let {
                cryptoManager.encryptMessageText(clean, it, "msg:${thread.id}:${message.id}")
            }
            val payload = hashMapOf<String, Any>(
                "text" to if (encrypted != null) "" else clean,
                "edited" to true,
                "editedAtMillis" to System.currentTimeMillis(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).apply {
                if (encrypted != null) {
                    put("ciphertext", encrypted.ciphertextBase64)
                    put("iv", encrypted.ivBase64)
                }
            }
            messagesCol(thread.id).document(message.id).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun toggleMessageReaction(chatId: String, message: ChatMessage, emoji: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            val updatedMap = MessageReactionHelper.toggleUidReaction(message.uidReactions, uid, emoji)
            messagesCol(chatId).document(message.id).update(
                mapOf(
                    "reactions" to updatedMap,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateMessageFlag(
        chatId: String,
        messageId: String,
        perUserMapField: String,
        value: Boolean
    ): Result<Unit> {
        return try {
            val uid = requireUserId()
            messagesCol(chatId).document(messageId).update(
                mapOf(
                    "$perUserMapField.$uid" to value,
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteMessageForEveryone(chatId: String, messageId: String): Result<Unit> {
        return try {
            requireUserId()
            messagesCol(chatId).document(messageId).update(
                mapOf(
                    "deletedForEveryone" to true,
                    "text" to "This message was deleted",
                    "ciphertext" to "",
                    "iv" to "",
                    "updatedAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun postStatus(
        authorName: String,
        ownerPhoneE164: String,
        caption: String,
        statusType: String,
        bgColorHex: Long,
        mediaUri: Uri?,
        privacyMode: String,
        selectedTargetUids: List<String>,
        allContactUids: List<String>
    ): Result<Unit> {
        val cleanCaption = caption.trim().take(500)
        if (cleanCaption.isEmpty()) return Result.failure(IllegalArgumentException("Status caption cannot be empty"))
        return try {
            val uid = requireUserId()
            val statusId = "st_${UUID.randomUUID().toString().replace("-", "").take(14)}"
            val mediaUrl = if (mediaUri != null) {
                storageMediaManager.uploadUserAvatarOrStatusMedia("statuses/$uid/$statusId", mediaUri)
                    .getOrElse { return Result.failure(it) }.downloadUrl
            } else ""

            val allowedUids = when (privacyMode) {
                "ONLY_SHARE_WITH" -> (selectedTargetUids + uid).distinct()
                "EXCEPT" -> ((allContactUids - selectedTargetUids.toSet()) + uid).distinct()
                else -> (allContactUids + uid).distinct()
            }
            val excludedUids = if (privacyMode == "EXCEPT") selectedTargetUids.distinct() else emptyList()
            val expiresAt = Timestamp(Date(System.currentTimeMillis() + 24L * 3600L * 1000L))

            val payload = hashMapOf<String, Any>(
                "ownerUid" to uid,
                "ownerPhoneE164" to ownerPhoneE164,
                "authorName" to authorName.ifBlank { "Whatsup User" }.take(80),
                "statusType" to statusType,
                "caption" to cleanCaption,
                "bgColorHex" to bgColorHex,
                "privacyMode" to privacyMode,
                "allowedUids" to allowedUids,
                "excludedUids" to excludedUids,
                "viewedByCount" to 0L,
                "expiresAt" to expiresAt,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            ).apply {
                if (mediaUrl.isNotBlank()) put("mediaUrl", mediaUrl)
            }
            statusesCol().document(statusId).set(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, "statuses")
            Result.failure(e)
        }
    }

    suspend fun markStatusViewed(statusId: String, viewerName: String, currentCount: Long): Result<Unit> {
        return try {
            val uid = requireUserId()
            val statusRef = statusesCol().document(statusId)
            val viewerRef = statusRef.collection("viewers").document(uid)
            val alreadyViewed = viewerRef.get().await().exists()
            if (!alreadyViewed) {
                val batch = db.batch()
                batch.set(
                    viewerRef,
                    mapOf(
                        "viewerUid" to uid,
                        "viewerName" to viewerName.ifBlank { "Whatsup User" }.take(80),
                        "viewedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.update(
                    statusRef,
                    mapOf(
                        "viewedByCount" to currentCount + 1L,
                        "updatedAt" to FieldValue.serverTimestamp()
                    )
                )
                batch.commit().await()
            }
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deleteStatus(statusId: String): Result<Unit> {
        return try {
            requireUserId()
            statusesCol().document(statusId).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun blockUser(targetUid: String, phoneE164: String, displayName: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            blockedCol(uid).document(targetUid).set(
                mapOf(
                    "blockedUid" to targetUid,
                    "phoneE164" to phoneE164,
                    "displayName" to displayName,
                    "createdAt" to FieldValue.serverTimestamp()
                )
            ).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun unblockUser(targetUid: String): Result<Unit> {
        return try {
            val uid = requireUserId()
            blockedCol(uid).document(targetUid).delete().await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updateUserProfileSettings(updates: Map<String, Any>): Result<Unit> {
        return try {
            val uid = requireUserId()
            val payload = updates.toMutableMap().apply { put("updatedAt", FieldValue.serverTimestamp()) }
            userDoc(uid).update(payload).await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, "users")
            Result.failure(e)
        }
    }

    suspend fun uploadUserAvatar(uri: Uri): Result<String> {
        return try {
            val uid = requireUserId()
            val uploaded = storageMediaManager.uploadUserAvatarOrStatusMedia(
                "avatars/$uid/profile_${System.currentTimeMillis()}.jpg",
                uri
            ).getOrElse { return Result.failure(it) }
            updateUserProfileSettings(mapOf("photoUrl" to uploaded.downloadUrl))
            Result.success(uploaded.downloadUrl)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun fetchPeerProfiles(uids: List<String>): Map<String, UserProfile> {
        if (uids.isEmpty()) return emptyMap()
        val result = mutableMapOf<String, UserProfile>()
        uids.distinct().forEach { uid ->
            runCatching {
                val snap = userDoc(uid).get().await()
                snap.toObject(UserProfile::class.java)?.let { result[uid] = it }
            }
        }
        return result
    }

    private fun deriveConversationAesKey(myUid: String, thread: ChatThread): ByteArray? {
        if (thread.chatType == "DIRECT" && thread.peerIdentityPublicKey.isNotBlank()) {
            return runCatching {
                cryptoManager.deriveDirectConversationKey(myUid, thread.peerIdentityPublicKey, thread.id)
            }.getOrNull()
        }
        val wrapped = thread.wrappedGroupKeys[myUid] ?: return null
        val creatorPub = if (thread.createdByUid == myUid) {
            cryptoManager.getPublicKeyBase64(myUid)
        } else {
            thread.peerIdentityPublicKey
        }
        if (creatorPub.isBlank()) return null
        return cryptoManager.unwrapGroupKey(myUid, creatorPub, wrapped, thread.id)
    }

    @Suppress("UNCHECKED_CAST")
    private fun mapConversationDoc(
        doc: DocumentSnapshot,
        myUid: String,
        myPubKey: String,
        contactsByUid: Map<String, VerifiedContact>
    ): ChatThread? {
        val type = doc.getString("type") ?: "DIRECT"
        val participants = (doc.get("participantUids") as? List<String>).orEmpty()
        val admins = (doc.get("adminUids") as? List<String>).orEmpty()
        val peerUid = if (type == "DIRECT") participants.firstOrNull { it != myUid }.orEmpty() else doc.getString("createdByUid").orEmpty()
        val contact = contactsByUid[peerUid]
        val wrappedKeys = (doc.get("wrappedGroupKeys") as? Map<String, String>).orEmpty()

        val peerPub = contact?.identityPublicKey.orEmpty()
        val safetyCode = if (type == "DIRECT") {
            WhatsupCryptoManager.computeSafetyNumber(myPubKey, peerPub)
        } else {
            "Group Key Verified (${participants.size} members)"
        }

        val dummyThreadForKey = ChatThread(
            id = doc.id,
            chatType = type,
            peerUid = peerUid,
            peerIdentityPublicKey = peerPub,
            createdByUid = doc.getString("createdByUid").orEmpty(),
            wrappedGroupKeys = wrappedKeys
        )
        val convKey = deriveConversationAesKey(myUid, dummyThreadForKey)
        val previewCipher = doc.getString("lastMessageCiphertext").orEmpty()
        val previewIv = doc.getString("lastMessageIv").orEmpty()
        val decryptedPreview = if (previewCipher.isNotBlank() && previewIv.isNotBlank() && convKey != null) {
            cryptoManager.decryptMessageText(previewCipher, previewIv, convKey, "preview:${doc.id}")
        } else null

        val unreadCounts = (doc.get("unreadCounts") as? Map<String, Any>).orEmpty()
        val typingMap = (doc.get("typingUids") as? Map<String, Any>).orEmpty()
        val pinnedBy = (doc.get("pinnedBy") as? Map<String, Any>).orEmpty()
        val archivedBy = (doc.get("archivedBy") as? Map<String, Any>).orEmpty()
        val mutedBy = (doc.get("mutedBy") as? Map<String, Any>).orEmpty()
        val lockedBy = (doc.get("lockedBy") as? Map<String, Any>).orEmpty()
        val wallpaperBy = (doc.get("wallpaperBy") as? Map<String, Any>).orEmpty()

        val peerTyping = typingMap.any { (k, v) -> k != myUid && v == true }
        val resolvedTitle = when {
            type == "DIRECT" && contact != null -> contact.savedName
            else -> doc.getString("title").orEmpty()
        }

        return ChatThread(
            id = doc.id,
            userId = myUid,
            title = resolvedTitle.ifBlank { "Whatsup Chat" },
            phone = contact?.phoneE164.orEmpty(),
            peerUid = peerUid,
            peerIdentityPublicKey = peerPub,
            participantUids = participants,
            adminUids = admins,
            createdByUid = doc.getString("createdByUid").orEmpty(),
            groupDescription = doc.getString("groupDescription").orEmpty(),
            groupPhotoUrl = doc.getString("groupPhotoUrl").orEmpty(),
            inviteCode = doc.getString("inviteCode"),
            chatType = type,
            lastMessage = decryptedPreview ?: doc.getString("lastMessagePreview").orEmpty(),
            lastMessageTimeLabel = doc.getString("lastMessageTimeLabel").orEmpty(),
            lastMessageTick = doc.getString("lastMessageTick") ?: "SENT",
            unreadCount = (unreadCounts[myUid] as? Number)?.toLong() ?: 0L,
            pinned = pinnedBy[myUid] == true,
            archived = archivedBy[myUid] == true,
            muted = mutedBy[myUid] == true,
            locked = lockedBy[myUid] == true,
            online = contact?.online == true,
            typing = peerTyping,
            lastSeenText = if (contact?.online == true) "online" else formatLastSeen(contact?.lastSeenAt ?: 0L),
            disappearingMode = doc.getString("disappearingMode") ?: "OFF",
            wallpaperStyle = (wallpaperBy[myUid] as? String) ?: "DEFAULT",
            memberCount = participants.size.coerceAtLeast(1).toLong(),
            communityName = doc.getString("communityName"),
            onlyAdminCanSend = doc.getBoolean("onlyAdminCanSend") == true,
            bluetoothChat = doc.getBoolean("bluetoothChat") == true,
            encryptionCode = safetyCode,
            wrappedGroupKeys = wrappedKeys,
            sortOrder = doc.getLong("sortOrder") ?: 0L,
            createdAt = doc.getTimestamp("createdAt"),
            updatedAt = doc.getTimestamp("updatedAt")
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun mapMessageDoc(
        doc: DocumentSnapshot,
        myUid: String,
        convId: String,
        convKey: ByteArray?
    ): ChatMessage? {
        val senderUid = doc.getString("senderUid") ?: return null
        val deletedForEveryone = doc.getBoolean("deletedForEveryone") == true
        val deletedForMap = (doc.get("deletedFor") as? Map<String, Any>).orEmpty()
        val starredMap = (doc.get("starredBy") as? Map<String, Any>).orEmpty()
        val viewOnceMap = (doc.get("viewOnceOpenedBy") as? Map<String, Any>).orEmpty()
        val uidReactions = (doc.get("reactions") as? Map<String, Any>).orEmpty()
            .mapValues { it.value.toString() }
        val (reactionCounts, myReaction) = MessageReactionHelper.summarizeByEmoji(uidReactions, myUid)

        val ciphertext = doc.getString("ciphertext").orEmpty()
        val iv = doc.getString("iv").orEmpty()
        val rawPlain = doc.getString("text").orEmpty()
        val displayText = when {
            deletedForEveryone -> "🚫 This message was deleted"
            ciphertext.isNotBlank() && iv.isNotBlank() && convKey != null -> {
                cryptoManager.decryptMessageText(ciphertext, iv, convKey, "msg:$convId:${doc.id}")
                    ?: rawPlain.ifBlank { "🔒 Encrypted message (safety key updated)" }
            }
            else -> rawPlain.ifBlank { "🔒 Encrypted message" }
        }

        return ChatMessage(
            id = doc.id,
            userId = senderUid,
            chatId = convId,
            senderName = doc.getString("senderName").orEmpty(),
            senderPhone = doc.getString("senderPhone").orEmpty(),
            fromMe = senderUid == myUid,
            text = displayText,
            ciphertext = ciphertext.ifBlank { null },
            iv = iv.ifBlank { null },
            messageType = doc.getString("messageType") ?: "TEXT",
            tickStatus = doc.getString("tickStatus") ?: "SENT",
            viaBluetooth = doc.getBoolean("viaBluetooth") == true,
            edited = doc.getBoolean("edited") == true,
            editedAtMillis = doc.getLong("editedAtMillis"),
            starred = starredMap[myUid] == true,
            deletedForEveryone = deletedForEveryone,
            deletedForMe = deletedForMap[myUid] == true,
            viewOnceOpened = viewOnceMap[myUid] == true,
            replyToText = doc.getString("replyToText"),
            replyToSender = doc.getString("replyToSender"),
            mediaStoragePath = doc.getString("mediaStoragePath"),
            mediaKeyBase64 = doc.getString("mediaKeyBase64"),
            mediaMeta = doc.getString("mediaMeta"),
            expiresAtMillis = doc.getLong("expiresAtMillis"),
            scheduledForMillis = doc.getLong("scheduledForMillis"),
            reactions = reactionCounts,
            uidReactions = uidReactions,
            myReaction = myReaction,
            timeLabel = doc.getString("timeLabel") ?: "now",
            createdAt = doc.getTimestamp("createdAt"),
            updatedAt = doc.getTimestamp("updatedAt")
        )
    }

    @Suppress("UNCHECKED_CAST")
    private fun mapStatusDoc(doc: DocumentSnapshot, myUid: String, now: Timestamp): StatusUpdate? {
        val expiresAt = doc.getTimestamp("expiresAt")
        if (expiresAt != null && expiresAt.toDate().time <= now.toDate().time) {
            return null
        }
        val ownerUid = doc.getString("ownerUid") ?: return null
        val created = doc.getTimestamp("createdAt")?.toDate()
        val timeLabel = if (created != null) {
            SimpleDateFormat("h:mm a", Locale.getDefault()).format(created)
        } else "Just now"
        return StatusUpdate(
            id = doc.id,
            userId = ownerUid,
            ownerPhoneE164 = doc.getString("ownerPhoneE164").orEmpty(),
            authorName = doc.getString("authorName").orEmpty(),
            caption = doc.getString("caption").orEmpty(),
            mediaUrl = doc.getString("mediaUrl").orEmpty(),
            statusType = doc.getString("statusType") ?: "TEXT",
            bgColorHex = doc.getLong("bgColorHex") ?: 0xFF075E54L,
            privacyMode = doc.getString("privacyMode") ?: "ALL_CONTACTS",
            allowedUids = (doc.get("allowedUids") as? List<String>).orEmpty(),
            excludedUids = (doc.get("excludedUids") as? List<String>).orEmpty(),
            viewedByCount = doc.getLong("viewedByCount") ?: 0L,
            viewersSummary = "Visible for 24h • ${doc.getLong("viewedByCount") ?: 0L} views",
            timeLabel = timeLabel,
            viewed = ownerUid == myUid,
            expiresAtMillis = expiresAt?.toDate()?.time ?: 0L,
            createdAt = doc.getTimestamp("createdAt"),
            updatedAt = doc.getTimestamp("updatedAt")
        )
    }

    private fun formatLastSeen(lastSeenMs: Long): String {
        if (lastSeenMs <= 0L) return "tap for info"
        val fmt = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
        return "last seen ${fmt.format(Date(lastSeenMs))}"
    }
}
