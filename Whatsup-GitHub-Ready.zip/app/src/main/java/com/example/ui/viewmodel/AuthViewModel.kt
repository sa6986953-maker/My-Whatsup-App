package com.example.ui.viewmodel

import android.app.Activity
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.CountryDialCode
import com.example.core.PhoneNumberUtils
import com.example.core.PreferencesManager
import com.example.core.SmsRetrieverHelper
import com.example.data.repository.AuthRepository
import com.example.data.repository.PhoneVerificationEvent
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class AuthStage {
    PHONE_ENTRY,
    OTP_ENTRY,
    TWO_STEP_CHALLENGE,
    PROFILE_SETUP,
    READY
}

object AuthRateLimitPolicy {
    const val RESEND_COOLDOWN_SECONDS = 60
    const val MAX_RESENDS_PER_SESSION = 5
    const val MAX_VERIFY_ATTEMPTS = 5
}

data class AuthUiState(
    val selectedCountry: CountryDialCode = PhoneNumberUtils.defaultCountry,
    val phoneNumberInput: String = "",
    val normalizedE164: String = "",
    val otpCodeInput: String = "",
    val stage: AuthStage = AuthStage.PHONE_ENTRY,
    val resendCooldownSeconds: Int = 0,
    val resendsUsed: Int = 0,
    val verifyAttemptsUsed: Int = 0,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val infoBanner: String? = null,
    val profileNameInput: String = "",
    val profileAboutInput: String = "Hey there! I am using Whatsup.",
    val twoStepPinInput: String = "",
    val twoStepConfirmInput: String = "",
    val twoStepHintInput: String = "",
    val showPinSetupInOnboarding: Boolean = false
)

class AuthViewModel(
    private val authRepository: AuthRepository,
    private val preferencesManager: PreferencesManager,
    private val db: FirebaseFirestore
) : ViewModel() {

    val currentUser: StateFlow<FirebaseUser?> = authRepository.observeAuthUser()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = authRepository.currentUser()
        )

    private val _uiState = MutableStateFlow(AuthUiState())
    val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

    private var verificationId: String? = null
    private var forceResendToken: PhoneAuthProvider.ForceResendingToken? = null
    private var countdownJob: Job? = null
    private var smsObserverJob: Job? = null

    fun selectCountry(country: CountryDialCode) {
        _uiState.value = _uiState.value.copy(
            selectedCountry = country,
            errorMessage = null
        )
    }

    fun updatePhoneNumber(input: String) {
        val cleaned = input.filter { it.isDigit() || it == ' ' || it == '+' || it == '-' }.take(18)
        _uiState.value = _uiState.value.copy(
            phoneNumberInput = cleaned,
            errorMessage = null
        )
    }

    fun updateOtpCode(input: String) {
        val digits = input.filter { it.isDigit() }.take(6)
        _uiState.value = _uiState.value.copy(
            otpCodeInput = digits,
            errorMessage = null
        )
    }

    fun startSmsAutoDetection(context: Context) {
        if (smsObserverJob != null) return
        smsObserverJob = viewModelScope.launch {
            SmsRetrieverHelper.observeIncomingOtp(context).collect { detectedOtp ->
                if (_uiState.value.stage == AuthStage.OTP_ENTRY) {
                    _uiState.value = _uiState.value.copy(
                        otpCodeInput = detectedOtp,
                        infoBanner = "OTP auto-detected from SMS"
                    )
                    verifyEnteredOtp()
                }
            }
        }
    }

    fun requestOtp(activity: Activity, isResend: Boolean = false) {
        val current = _uiState.value
        if (current.isLoading) return

        if (isResend) {
            if (current.resendCooldownSeconds > 0) {
                _uiState.value = current.copy(
                    errorMessage = "Please wait ${current.resendCooldownSeconds}s before resending OTP."
                )
                return
            }
            if (current.resendsUsed >= AuthRateLimitPolicy.MAX_RESENDS_PER_SESSION) {
                _uiState.value = current.copy(
                    errorMessage = "Maximum OTP resend limit (${AuthRateLimitPolicy.MAX_RESENDS_PER_SESSION}) reached. Try again later."
                )
                return
            }
        }

        val e164 = PhoneNumberUtils.normalizeToE164(
            rawInput = current.phoneNumberInput,
            defaultRegionIso = current.selectedCountry.isoCode,
            dialCodePrefix = current.selectedCountry.dialCode
        )
        if (e164 == null) {
            _uiState.value = current.copy(
                errorMessage = "Enter a valid ${current.selectedCountry.name} phone number (e.g. ${current.selectedCountry.dialCode} ${current.selectedCountry.exampleHint})"
            )
            return
        }

        _uiState.value = current.copy(
            isLoading = true,
            normalizedE164 = e164,
            errorMessage = null,
            infoBanner = "Sending SMS verification code to ${PhoneNumberUtils.formatDisplay(e164)}..."
        )

        authRepository.sendPhoneOtp(
            activity = activity,
            phoneE164 = e164,
            resendToken = if (isResend) forceResendToken else null
        ) { event ->
            when (event) {
                is PhoneVerificationEvent.CodeSent -> {
                    verificationId = event.verificationId
                    forceResendToken = event.resendToken
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        stage = AuthStage.OTP_ENTRY,
                        resendsUsed = if (isResend) _uiState.value.resendsUsed + 1 else 0,
                        verifyAttemptsUsed = 0,
                        errorMessage = null,
                        infoBanner = "6-digit SMS code sent to ${PhoneNumberUtils.formatDisplay(e164)}"
                    )
                    startResendCountdown()
                }
                is PhoneVerificationEvent.InstantVerified -> {
                    completePhoneCredentialSignIn(event.credential)
                }
                is PhoneVerificationEvent.Failed -> {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = event.userFriendlyMessage,
                        infoBanner = null
                    )
                }
            }
        }
    }

    private fun startResendCountdown() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            for (sec in AuthRateLimitPolicy.RESEND_COOLDOWN_SECONDS downTo 0) {
                _uiState.value = _uiState.value.copy(resendCooldownSeconds = sec)
                if (sec > 0) delay(1000L)
            }
        }
    }

    fun verifyEnteredOtp() {
        val current = _uiState.value
        if (current.isLoading) return

        if (current.verifyAttemptsUsed >= AuthRateLimitPolicy.MAX_VERIFY_ATTEMPTS) {
            _uiState.value = current.copy(
                errorMessage = "Too many failed OTP attempts (${AuthRateLimitPolicy.MAX_VERIFY_ATTEMPTS}). Request a new OTP."
            )
            return
        }
        val vid = verificationId
        if (vid.isNullOrBlank()) {
            _uiState.value = current.copy(errorMessage = "No active verification session. Please send OTP first.")
            return
        }
        if (current.otpCodeInput.length != 6) {
            _uiState.value = current.copy(errorMessage = "Enter the 6-digit SMS verification code.")
            return
        }

        _uiState.value = current.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val result = authRepository.verifyOtpCode(vid, current.otpCodeInput)
            result.fold(
                onSuccess = { user -> handlePostFirebaseAuth(user) },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        verifyAttemptsUsed = current.verifyAttemptsUsed + 1,
                        errorMessage = error.localizedMessage ?: "OTP verification failed."
                    )
                }
            )
        }
    }

    private fun completePhoneCredentialSignIn(credential: PhoneAuthCredential) {
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            val result = authRepository.signInWithPhoneCredential(credential)
            result.fold(
                onSuccess = { user -> handlePostFirebaseAuth(user) },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.localizedMessage ?: "Verification failed."
                    )
                }
            )
        }
    }

    suspend fun evaluateAuthenticatedSession(user: FirebaseUser, verifiedTwoStepUid: String) {
        val verifiedPhone = user.phoneNumber?.takeIf { it.isNotBlank() }
            ?: _uiState.value.normalizedE164
        if (verifiedPhone.isNotBlank()) {
            preferencesManager.setVerifiedPhoneNumber(verifiedPhone)
        }
        val (hasProfile, twoStepEnabled) = authRepository.checkHasProfileAndTwoStep(db, user.uid)
        val nextStage = when {
            twoStepEnabled && verifiedTwoStepUid != user.uid -> AuthStage.TWO_STEP_CHALLENGE
            !hasProfile -> AuthStage.PROFILE_SETUP
            else -> AuthStage.READY
        }
        _uiState.value = _uiState.value.copy(
            isLoading = false,
            normalizedE164 = verifiedPhone,
            stage = nextStage,
            profileNameInput = _uiState.value.profileNameInput.ifBlank { user.displayName.orEmpty() },
            errorMessage = null
        )
    }

    private suspend fun handlePostFirebaseAuth(user: FirebaseUser) {
        val verifiedPhone = user.phoneNumber?.takeIf { it.isNotBlank() }
            ?: _uiState.value.normalizedE164
        if (verifiedPhone.isNotBlank()) {
            preferencesManager.setVerifiedPhoneNumber(verifiedPhone)
        }
        val (hasProfile, twoStepEnabled) = authRepository.checkHasProfileAndTwoStep(db, user.uid)
        when {
            twoStepEnabled -> {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    stage = AuthStage.TWO_STEP_CHALLENGE,
                    twoStepPinInput = "",
                    infoBanner = "Enter your Two-Step Verification PIN to unlock your account on this device."
                )
            }
            !hasProfile -> {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    stage = AuthStage.PROFILE_SETUP,
                    infoBanner = "Phone verified! Set up your profile name to finish."
                )
            }
            else -> {
                preferencesManager.setTwoStepVerifiedUid(user.uid)
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    stage = AuthStage.READY
                )
            }
        }
    }

    fun updateTwoStepPinInput(pin: String) {
        _uiState.value = _uiState.value.copy(
            twoStepPinInput = pin.filter { it.isDigit() }.take(6),
            errorMessage = null
        )
    }

    fun updateTwoStepConfirmInput(pin: String) {
        _uiState.value = _uiState.value.copy(
            twoStepConfirmInput = pin.filter { it.isDigit() }.take(6),
            errorMessage = null
        )
    }

    fun updateTwoStepHintInput(hint: String) {
        _uiState.value = _uiState.value.copy(
            twoStepHintInput = hint.take(120),
            errorMessage = null
        )
    }

    fun verifyTwoStepChallenge() {
        val pin = _uiState.value.twoStepPinInput
        if (pin.length != 6) {
            _uiState.value = _uiState.value.copy(errorMessage = "Enter your 6-digit Two-Step PIN.")
            return
        }
        val uid = authRepository.currentUser()?.uid ?: return
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            authRepository.verifyTwoStepPinServerSide(pin).fold(
                onSuccess = { ok ->
                    if (ok) {
                        preferencesManager.setTwoStepVerifiedUid(uid)
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            stage = AuthStage.READY
                        )
                    } else {
                        _uiState.value = _uiState.value.copy(
                            isLoading = false,
                            errorMessage = "Incorrect Two-Step PIN."
                        )
                    }
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.localizedMessage ?: "PIN verification failed."
                    )
                }
            )
        }
    }

    fun recoverTwoStepPin(recoveryAnswer: String, newPin: String, confirmPin: String) {
        if (newPin.length != 6 || newPin != confirmPin) {
            _uiState.value = _uiState.value.copy(errorMessage = "New 6-digit PINs must match.")
            return
        }
        val uid = authRepository.currentUser()?.uid ?: return
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            authRepository.recoverTwoStepPinServerSide(recoveryAnswer, newPin).fold(
                onSuccess = {
                    preferencesManager.setTwoStepVerifiedUid(uid)
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        stage = AuthStage.READY,
                        infoBanner = "Two-Step PIN recovered and updated."
                    )
                },
                onFailure = { err ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = err.localizedMessage ?: "Recovery failed."
                    )
                }
            )
        }
    }

    fun updateProfileNameInput(name: String) {
        _uiState.value = _uiState.value.copy(
            profileNameInput = name.take(60),
            errorMessage = null
        )
    }

    fun updateProfileAboutInput(about: String) {
        _uiState.value = _uiState.value.copy(
            profileAboutInput = about.take(160),
            errorMessage = null
        )
    }

    fun toggleOnboardingTwoStep(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(showPinSetupInOnboarding = enabled, errorMessage = null)
    }

    fun completeOnboardingProfile(onRegisterProfile: suspend (displayName: String, about: String) -> Result<Unit>) {
        val state = _uiState.value
        val cleanName = state.profileNameInput.trim()
        if (cleanName.isEmpty()) {
            _uiState.value = state.copy(errorMessage = "Please enter your display name.")
            return
        }
        if (state.showPinSetupInOnboarding) {
            if (state.twoStepPinInput.length != 6 || state.twoStepPinInput != state.twoStepConfirmInput) {
                _uiState.value = state.copy(errorMessage = "Two-Step PIN must be 6 matching digits.")
                return
            }
        }
        val uid = authRepository.currentUser()?.uid ?: return
        _uiState.value = state.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            onRegisterProfile(cleanName, state.profileAboutInput.trim().ifBlank { "Hey there! I am using Whatsup." })
                .onFailure { err ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = err.localizedMessage ?: "Failed to create profile."
                    )
                    return@launch
                }

            var banner: String? = null
            if (state.showPinSetupInOnboarding) {
                authRepository.setTwoStepPinServerSide(
                    pin = state.twoStepPinInput,
                    recoveryHint = state.twoStepHintInput
                ).onFailure { err ->
                    banner = "Profile created, but Two-Step PIN setup requires Cloud Functions: ${err.localizedMessage}"
                }
            }
            preferencesManager.setTwoStepVerifiedUid(uid)
            _uiState.value = _uiState.value.copy(
                isLoading = false,
                stage = AuthStage.READY,
                infoBanner = banner
            )
        }
    }

    fun editPhoneNumberAgain() {
        countdownJob?.cancel()
        _uiState.value = _uiState.value.copy(
            stage = AuthStage.PHONE_ENTRY,
            otpCodeInput = "",
            resendCooldownSeconds = 0,
            errorMessage = null,
            infoBanner = null
        )
    }

    fun linkGoogleAccountOptional(activity: Activity) {
        if (_uiState.value.isLoading) return
        _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
        viewModelScope.launch {
            authRepository.linkOrSignInWithGoogleOptional(activity).fold(
                onSuccess = {
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        infoBanner = "Google account linked for optional backup."
                    )
                },
                onFailure = { error ->
                    _uiState.value = _uiState.value.copy(
                        isLoading = false,
                        errorMessage = error.localizedMessage ?: "Google linking cancelled or unavailable."
                    )
                }
            )
        }
    }

    fun signOut(context: Context) {
        countdownJob?.cancel()
        viewModelScope.launch {
            preferencesManager.clearSessionPrefs()
            authRepository.signOut(context)
            verificationId = null
            forceResendToken = null
            _uiState.value = AuthUiState()
        }
    }

    override fun onCleared() {
        super.onCleared()
        countdownJob?.cancel()
        smsObserverJob?.cancel()
    }
}
