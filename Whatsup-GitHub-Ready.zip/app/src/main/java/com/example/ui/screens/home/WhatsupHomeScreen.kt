package com.example.ui.screens.home

import android.app.Activity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.PersonSearch
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Update
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.ChatHistoryExporter
import com.example.core.PhoneNumberUtils
import com.example.data.model.ChatMessage
import com.example.data.model.ChatThread
import com.example.data.model.UiState
import com.example.data.model.VerifiedContact
import com.example.data.repository.PhoneVerificationEvent
import com.example.ui.screens.ai.WhatsupAiSheet
import com.example.ui.screens.bluetooth.BluetoothMeshSheet
import com.example.ui.screens.calls.ActiveCallOverlay
import com.example.ui.screens.calls.CallsScreen
import com.example.ui.screens.chat.ChatScreen
import com.example.ui.screens.groups.GroupsAndCommunityScreen
import com.example.ui.screens.settings.ExportChatHistoryDialog
import com.example.ui.screens.settings.SettingsScreen
import com.example.ui.screens.updates.UpdatesScreen
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.DarkTopBar
import com.example.ui.theme.MissedCallRed
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.AiAssistantViewModel
import com.example.ui.viewmodel.ContactLookupUiState
import com.example.ui.viewmodel.WhatsupViewModel

private enum class HomeTab(val label: String) {
    CHATS("Chats"),
    UPDATES("Updates"),
    CALLS("Calls"),
    GROUPS("Groups")
}

@Composable
fun WhatsupMainApp(
    viewModel: WhatsupViewModel,
    aiViewModel: AiAssistantViewModel,
    initialChatId: String? = null,
    isGoogleLinked: Boolean = false,
    linkedEmail: String? = null,
    isAuthLoading: Boolean = false,
    authErrorMessage: String? = null,
    onConnectGoogleAccount: () -> Unit = {},
    onSendChangePhoneOtp: (
        activity: Activity,
        newPhoneE164: String,
        onEvent: (PhoneVerificationEvent) -> Unit
    ) -> Unit,
    onConfirmChangePhoneOtp: suspend (oldPhoneE164: String, newPhoneE164: String, verificationId: String, otpCode: String) -> Result<Unit>,
    onSignOut: () -> Unit
) {
    val chatsState by viewModel.chatsState.collectAsStateWithLifecycle()
    val messagesState by viewModel.activeMessagesState.collectAsStateWithLifecycle()
    val statusesState by viewModel.statusesState.collectAsStateWithLifecycle()
    val callsState by viewModel.callsState.collectAsStateWithLifecycle()
    val profileState by viewModel.userProfile.collectAsStateWithLifecycle()
    val verifiedContacts by viewModel.verifiedContactsState.collectAsStateWithLifecycle()
    val blockedUsers by viewModel.blockedUsersState.collectAsStateWithLifecycle()
    val lookupState by viewModel.lookupState.collectAsStateWithLifecycle()
    val localPrefs by viewModel.localPrefs.collectAsStateWithLifecycle()
    val meshStatus by viewModel.meshStatus.collectAsStateWithLifecycle()
    val selectedChatId by viewModel.selectedChatId.collectAsStateWithLifecycle()
    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val actionMessage by viewModel.actionMessage.collectAsStateWithLifecycle()
    val exportState by viewModel.exportState.collectAsStateWithLifecycle()
    val exportedFiles by viewModel.exportedFiles.collectAsStateWithLifecycle()
    val recordingState by viewModel.recordingState.collectAsStateWithLifecycle()
    val voicePlaybackState by viewModel.voicePlaybackState.collectAsStateWithLifecycle()
    val incomingRingingCalls by viewModel.incomingRingingCalls.collectAsStateWithLifecycle()
    val activeCallRecord by viewModel.activeCallRecord.collectAsStateWithLifecycle()
    val webrtcState by viewModel.webrtcState.collectAsStateWithLifecycle()
    val activeCallSeconds by viewModel.activeCallSeconds.collectAsStateWithLifecycle()
    val mediaCacheBytes by viewModel.mediaCacheBytes.collectAsStateWithLifecycle()

    val inlineSummaryState by aiViewModel.inlineSummaryState.collectAsStateWithLifecycle()
    val suggestedRepliesState by aiViewModel.suggestedRepliesState.collectAsStateWithLifecycle()
    val context = LocalContext.current

    LaunchedEffect(initialChatId) {
        if (!initialChatId.isNullOrBlank()) {
            viewModel.selectChat(initialChatId)
        }
    }

    LaunchedEffect(selectedChatId) {
        aiViewModel.onChatThreadChanged(selectedChatId)
    }

    var selectedTabIndex by remember { mutableIntStateOf(0) }
    var searchActive by remember { mutableStateOf(false) }
    var showOverflowMenu by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var showBluetoothSheet by remember { mutableStateOf(false) }
    var showNewChatDialog by remember { mutableStateOf(false) }
    var showAiSheet by remember { mutableStateOf(false) }
    var showChatExportDialog by remember { mutableStateOf(false) }
    var aiTargetMessage by remember { mutableStateOf<ChatMessage?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(actionMessage) {
        actionMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearActionMessage()
        }
    }

    val quickStatusPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.postStatus(
                caption = "Photo Update",
                statusType = "PHOTO",
                bgColorHex = 0xFF075E54L,
                mediaUri = uri,
                privacyMode = "ALL_CONTACTS",
                selectedTargetUids = emptyList()
            )
            selectedTabIndex = HomeTab.UPDATES.ordinal
        }
    }

    val allChats = (chatsState as? UiState.Success)?.data ?: emptyList()
    val selectedChat = allChats.firstOrNull { it.id == selectedChatId }
    val profile = (profileState as? UiState.Success)?.data

    // Active Real WebRTC Call Overlay takes top priority
    val liveCall = activeCallRecord
    if (liveCall != null) {
        ActiveCallOverlay(
            call = liveCall,
            currentUserId = viewModel.currentUserId,
            webrtcManager = viewModel.webrtcManager,
            webrtcState = webrtcState,
            durationSeconds = activeCallSeconds,
            onEndCall = viewModel::endActiveCall
        )
        return
    }

    fun startDirectOrLookupCall(chat: ChatThread, isVideo: Boolean) {
        if (chat.chatType != "DIRECT" || chat.peerUid.isBlank()) {
            showNewChatDialog = true
            return
        }
        val peerContact = verifiedContacts.firstOrNull { it.contactUid == chat.peerUid }
            ?: VerifiedContact(
                contactUid = chat.peerUid,
                savedName = chat.title,
                phoneE164 = chat.phone,
                identityPublicKey = chat.peerIdentityPublicKey
            )
        viewModel.startCallWithContact(peerContact, isVideo = isVideo)
    }

    if (showSettings) {
        SettingsScreen(
            currentUserId = viewModel.currentUserId,
            profile = profile,
            localPrefs = localPrefs,
            allChats = allChats,
            blockedUsers = blockedUsers,
            mediaCacheBytes = mediaCacheBytes,
            exportState = exportState,
            exportedFiles = exportedFiles,
            isGoogleLinked = isGoogleLinked,
            linkedEmail = linkedEmail,
            isAuthLoading = isAuthLoading,
            authErrorMessage = authErrorMessage,
            onBack = { showSettings = false },
            onToggleDarkMode = viewModel::toggleDarkMode,
            onUpdatePrivacySettings = viewModel::updatePrivacyAndSettings,
            onUploadAvatar = viewModel::uploadMyAvatar,
            onSetAppLock = viewModel::setAppLock,
            onSetTwoStepPin = viewModel::setTwoStepPin,
            onDisableTwoStepPin = viewModel::disableTwoStepPin,
            onSendChangePhoneOtp = onSendChangePhoneOtp,
            onConfirmChangePhoneOtp = onConfirmChangePhoneOtp,
            onUnblockUser = viewModel::unblockUser,
            onClearMediaCache = viewModel::clearLocalMediaCache,
            onSaveTurnConfig = viewModel::saveTurnServerConfig,
            onOpenBluetoothMesh = { showBluetoothSheet = true },
            onSelectNotificationSound = viewModel::setNotificationSound,
            onRefreshExports = { viewModel.refreshExportedFiles(context) },
            onExportChatHistory = { chatId, format -> viewModel.exportChatHistory(context, chatId, format) },
            onDeleteExportFile = { file -> viewModel.deleteExportedFile(context, file) },
            onResetExportState = viewModel::resetExportState,
            onConnectGoogleAccount = onConnectGoogleAccount,
            onSignOut = onSignOut
        )
    } else {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isExpandedScreen = maxWidth >= 840.dp
            val incomingCall = incomingRingingCalls.firstOrNull()

            Column(modifier = Modifier.fillMaxSize()) {
                if (incomingCall != null) {
                    IncomingCallBanner(
                        callerName = incomingCall.callerName,
                        isVideo = incomingCall.callType.contains("VIDEO"),
                        onAccept = { viewModel.acceptIncomingCall(incomingCall) },
                        onReject = { viewModel.rejectIncomingCall(incomingCall) }
                    )
                }

                Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    if (selectedChat != null && !isExpandedScreen) {
                        val isPeerBlocked = selectedChat.peerUid.isNotBlank() &&
                            blockedUsers.any { it.blockedUid == selectedChat.peerUid }
                        ChatScreen(
                            chat = selectedChat,
                            currentUserId = viewModel.currentUserId,
                            messagesState = messagesState,
                            meshStatus = meshStatus,
                            recordingState = recordingState,
                            voicePlaybackState = voicePlaybackState,
                            darkMode = localPrefs.darkMode,
                            hideBlueTicks = profile?.hideBlueTicks ?: false,
                            hideOnline = profile?.hideOnline ?: false,
                            hideLastSeen = profile?.hideLastSeen ?: false,
                            isPeerBlocked = isPeerBlocked,
                            allChats = allChats,
                            onBack = { viewModel.selectChat(null) },
                            onToggleBluetoothMode = viewModel::toggleOfflineBluetoothMode,
                            onSyncBluetooth = { viewModel.syncPendingBluetooth(selectedChat) },
                            onTypingChanged = { isNonEmpty -> viewModel.notifyTyping(selectedChat.id, isNonEmpty) },
                            onSendMessage = { text, type, rText, rSender, meta, delayMins ->
                                viewModel.sendMessage(selectedChat, text, type, rText, rSender, meta, delayMins)
                            },
                            onSendUriAttachment = { uri, type, caption, viewOnce ->
                                viewModel.sendUriAttachment(selectedChat, uri, type, caption, viewOnce)
                            },
                            onStartVoiceRecording = { viewModel.voiceAudioManager.startRecording() },
                            onStopVoiceRecording = { discard -> viewModel.stopAndSendVoiceRecording(selectedChat, discard) },
                            onPlayVoiceMessage = viewModel::playVoiceMessage,
                            onDownloadMedia = viewModel::downloadMediaFile,
                            onEditMessage = { msg, newText -> viewModel.editMessage(selectedChat, msg, newText) },
                            onForwardMessage = { targetId, msg ->
                                val targetThread = allChats.firstOrNull { it.id == targetId }
                                if (targetThread != null) {
                                    viewModel.sendMessage(
                                        thread = targetThread,
                                        text = "↪ Forwarded: ${msg.text}",
                                        messageType = msg.messageType,
                                        replyToText = null,
                                        replyToSender = null,
                                        mediaMeta = msg.mediaMeta
                                    )
                                }
                            },
                            onStarMessage = { msg -> viewModel.toggleStarMessage(selectedChat.id, msg) },
                            onToggleReaction = { msg, emoji -> viewModel.toggleMessageReaction(selectedChat.id, msg, emoji) },
                            onDeleteForMe = { msgId -> viewModel.deleteMessageForMe(selectedChat.id, msgId) },
                            onDeleteForEveryone = { msgId -> viewModel.deleteMessageForEveryone(selectedChat.id, msgId) },
                            onOpenViewOnce = { msgId -> viewModel.openViewOnceMessage(selectedChat.id, msgId) },
                            onSetDisappearing = { mode -> viewModel.setDisappearingMode(selectedChat.id, mode) },
                            onSetWallpaper = { style -> viewModel.setWallpaperStyle(selectedChat.id, style) },
                            onToggleChatLock = { viewModel.toggleLockChat(selectedChat) },
                            onToggleBlockPeer = {
                                if (selectedChat.peerUid.isNotBlank()) {
                                    if (isPeerBlocked) {
                                        viewModel.unblockUser(selectedChat.peerUid)
                                    } else {
                                        viewModel.blockUser(selectedChat.peerUid, selectedChat.phone, selectedChat.title)
                                    }
                                }
                            },
                            onOpenAiAssistant = { msg ->
                                aiTargetMessage = msg
                                showAiSheet = true
                            },
                            inlineSummaryState = inlineSummaryState,
                            suggestedRepliesState = suggestedRepliesState,
                            onSummarizeThread = {
                                val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
                                aiViewModel.summarizeThreadInline(selectedChat.title, msgs)
                            },
                            onDismissSummary = aiViewModel::dismissInlineSummary,
                            onGenerateSuggestions = {
                                val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
                                aiViewModel.generateThreadSuggestions(selectedChat.title, msgs)
                            },
                            onDismissSuggestions = aiViewModel::dismissSuggestedReplies,
                            onOpenExportChat = {
                                viewModel.resetExportState()
                                showChatExportDialog = true
                            },
                            onStartVoiceCall = { startDirectOrLookupCall(selectedChat, isVideo = false) },
                            onStartVideoCall = { startDirectOrLookupCall(selectedChat, isVideo = true) }
                        )
                    } else {
                        val topBarColor = if (localPrefs.darkMode) DarkTopBar else WhatsupDarkGreen
                        val tabs = HomeTab.entries

                        Scaffold(
                            snackbarHost = { SnackbarHost(snackbarHostState) },
                            topBar = {
                                Surface(color = topBarColor, shadowElevation = 4.dp) {
                                    Column(modifier = Modifier.statusBarsPadding()) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(58.dp)
                                                .padding(horizontal = 16.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            if (searchActive) {
                                                OutlinedTextField(
                                                    value = searchQuery,
                                                    onValueChange = viewModel::updateSearchQuery,
                                                    placeholder = { Text("Search Whatsup...", color = Color.White.copy(alpha = 0.7f)) },
                                                    singleLine = true,
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .testTag("home_search_input")
                                                )
                                                IconButton(onClick = {
                                                    searchActive = false
                                                    viewModel.updateSearchQuery("")
                                                }) {
                                                    Icon(Icons.Filled.Close, contentDescription = "Close Search", tint = Color.White)
                                                }
                                            } else {
                                                Text(
                                                    text = "Whatsup",
                                                    style = MaterialTheme.typography.titleLarge,
                                                    color = Color.White,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.weight(1f)
                                                )

                                                Surface(
                                                    color = if (meshStatus.offlineModeActive) BluetoothBlue else Color.White.copy(alpha = 0.16f),
                                                    shape = RoundedCornerShape(16.dp),
                                                    modifier = Modifier
                                                        .clickable { showBluetoothSheet = true }
                                                        .testTag("home_bluetooth_chip")
                                                ) {
                                                    Row(
                                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Icon(
                                                            imageVector = Icons.Filled.BluetoothConnected,
                                                            contentDescription = "Bluetooth Mesh",
                                                            tint = Color.White,
                                                            modifier = Modifier.size(15.dp)
                                                        )
                                                        Spacer(modifier = Modifier.width(4.dp))
                                                        Text(
                                                            text = if (meshStatus.offlineModeActive) "BT Offline" else "Mesh",
                                                            style = MaterialTheme.typography.labelSmall,
                                                            color = Color.White,
                                                            fontWeight = FontWeight.Bold
                                                        )
                                                    }
                                                }

                                                IconButton(
                                                    onClick = {
                                                        quickStatusPhotoPicker.launch(
                                                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                                        )
                                                    },
                                                    modifier = Modifier.testTag("home_camera_button")
                                                ) {
                                                    Icon(Icons.Filled.CameraAlt, contentDescription = "Share Photo Status", tint = Color.White)
                                                }
                                                IconButton(
                                                    onClick = { searchActive = true },
                                                    modifier = Modifier.testTag("home_search_button")
                                                ) {
                                                    Icon(Icons.Filled.Search, contentDescription = "Search", tint = Color.White)
                                                }
                                                Box {
                                                    IconButton(
                                                        onClick = { showOverflowMenu = true },
                                                        modifier = Modifier.testTag("home_overflow_menu")
                                                    ) {
                                                        Icon(Icons.Filled.MoreVert, contentDescription = "Menu", tint = Color.White)
                                                    }
                                                    DropdownMenu(
                                                        expanded = showOverflowMenu,
                                                        onDismissRequest = { showOverflowMenu = false }
                                                    ) {
                                                        DropdownMenuItem(
                                                            text = { Text("New group") },
                                                            onClick = {
                                                                showOverflowMenu = false
                                                                selectedTabIndex = HomeTab.GROUPS.ordinal
                                                            }
                                                        )
                                                        DropdownMenuItem(
                                                            text = { Text("Offline Bluetooth Mesh") },
                                                            onClick = {
                                                                showOverflowMenu = false
                                                                showBluetoothSheet = true
                                                            }
                                                        )
                                                        DropdownMenuItem(
                                                            text = { Text("Find contact by number") },
                                                            onClick = {
                                                                showOverflowMenu = false
                                                                viewModel.resetContactLookup()
                                                                showNewChatDialog = true
                                                            }
                                                        )
                                                        DropdownMenuItem(
                                                            text = { Text("Settings") },
                                                            onClick = {
                                                                showOverflowMenu = false
                                                                viewModel.refreshMediaCacheSize()
                                                                showSettings = true
                                                            }
                                                        )
                                                    }
                                                }
                                            }
                                        }

                                        if (!isExpandedScreen) {
                                            TabRow(
                                                selectedTabIndex = selectedTabIndex,
                                                containerColor = topBarColor,
                                                contentColor = Color.White,
                                                indicator = { tabPositions ->
                                                    TabRowDefaults.SecondaryIndicator(
                                                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                                                        height = 3.dp,
                                                        color = Color.White
                                                    )
                                                }
                                            ) {
                                                tabs.forEachIndexed { index, tab ->
                                                    Tab(
                                                        selected = selectedTabIndex == index,
                                                        onClick = { selectedTabIndex = index },
                                                        modifier = Modifier.testTag("tab_${tab.name.lowercase()}"),
                                                        text = {
                                                            Text(
                                                                text = tab.label,
                                                                fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium,
                                                                maxLines = 1
                                                            )
                                                        }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            },
                            floatingActionButton = {
                                FloatingActionButton(
                                    onClick = {
                                        viewModel.resetContactLookup()
                                        showNewChatDialog = true
                                    },
                                    containerColor = WhatsupGreen,
                                    contentColor = Color.White,
                                    modifier = Modifier
                                        .navigationBarsPadding()
                                        .testTag("home_new_chat_fab")
                                ) {
                                    Icon(Icons.Filled.AddComment, contentDescription = "New Chat")
                                }
                            }
                        ) { innerPadding ->
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                                    .navigationBarsPadding()
                            ) {
                                if (isExpandedScreen) {
                                    NavigationRail {
                                        tabs.forEachIndexed { index, tab ->
                                            val icon = when (tab) {
                                                HomeTab.CHATS -> Icons.Filled.Chat
                                                HomeTab.UPDATES -> Icons.Filled.Update
                                                HomeTab.CALLS -> Icons.Filled.Call
                                                HomeTab.GROUPS -> Icons.Filled.Groups
                                            }
                                            NavigationRailItem(
                                                selected = selectedTabIndex == index,
                                                onClick = { selectedTabIndex = index },
                                                icon = { Icon(icon, contentDescription = tab.label) },
                                                label = { Text(tab.label) }
                                            )
                                        }
                                    }
                                }

                                Box(
                                    modifier = Modifier
                                        .weight(if (isExpandedScreen && selectedChat != null) 0.42f else 1f)
                                        .fillMaxHeight()
                                ) {
                                    when (tabs[selectedTabIndex]) {
                                        HomeTab.CHATS -> HomeChatsTab(
                                            chatsState = chatsState,
                                            searchQuery = searchQuery,
                                            hideBlueTicks = profile?.hideBlueTicks ?: false,
                                            hideOnline = profile?.hideOnline ?: false,
                                            appLockPin = localPrefs.appLockPin,
                                            onOpenChat = { viewModel.selectChat(it.id) },
                                            onTogglePin = viewModel::togglePinChat,
                                            onToggleArchive = viewModel::toggleArchiveChat,
                                            onToggleMute = viewModel::toggleMuteChat,
                                            onToggleLock = viewModel::toggleLockChat
                                        )
                                        HomeTab.UPDATES -> UpdatesScreen(
                                            statusesState = statusesState,
                                            currentUserId = viewModel.currentUserId,
                                            myDisplayName = profile?.displayName ?: "Whatsup User",
                                            verifiedContacts = verifiedContacts,
                                            onPostStatus = viewModel::postStatus,
                                            onMarkViewed = viewModel::markStatusViewed,
                                            onObserveViewers = viewModel::observeStatusViewers,
                                            onDeleteStatus = viewModel::deleteStatus,
                                            onReplyToStatus = viewModel::replyToStatus
                                        )
                                        HomeTab.CALLS -> CallsScreen(
                                            callsState = callsState,
                                            verifiedContacts = verifiedContacts,
                                            onCreateCallLink = viewModel::createJoinableCallLink,
                                            onStartCallWithContact = { contact, isVideo ->
                                                viewModel.startCallWithContact(contact, isVideo)
                                            }
                                        )
                                        HomeTab.GROUPS -> GroupsAndCommunityScreen(
                                            chatsState = chatsState,
                                            currentUserId = viewModel.currentUserId,
                                            verifiedContacts = verifiedContacts,
                                            onOpenChat = { viewModel.selectChat(it.id) },
                                            onToggleAdminOnlySend = viewModel::toggleAdminOnlySend,
                                            onCreateGroup = viewModel::createGroup,
                                            onJoinGroupByCode = viewModel::joinGroupViaInvite,
                                            onUpdateGroupDetails = viewModel::updateGroupDetails,
                                            onToggleGroupAdmin = viewModel::toggleGroupAdmin,
                                            onAddMemberToGroup = viewModel::addMemberToGroup,
                                            onRemoveMemberFromGroup = viewModel::removeMemberFromGroup,
                                            onFetchGroupParticipants = viewModel::fetchGroupParticipants
                                        )
                                    }
                                }

                                // Tablet Split-Pane Detail View
                                if (isExpandedScreen && selectedChat != null) {
                                    val isPeerBlocked = selectedChat.peerUid.isNotBlank() &&
                                        blockedUsers.any { it.blockedUid == selectedChat.peerUid }
                                    Box(
                                        modifier = Modifier
                                            .weight(0.58f)
                                            .fillMaxHeight()
                                    ) {
                                        ChatScreen(
                                            chat = selectedChat,
                                            currentUserId = viewModel.currentUserId,
                                            messagesState = messagesState,
                                            meshStatus = meshStatus,
                                            recordingState = recordingState,
                                            voicePlaybackState = voicePlaybackState,
                                            darkMode = localPrefs.darkMode,
                                            hideBlueTicks = profile?.hideBlueTicks ?: false,
                                            hideOnline = profile?.hideOnline ?: false,
                                            hideLastSeen = profile?.hideLastSeen ?: false,
                                            isPeerBlocked = isPeerBlocked,
                                            allChats = allChats,
                                            onBack = { viewModel.selectChat(null) },
                                            onToggleBluetoothMode = viewModel::toggleOfflineBluetoothMode,
                                            onSyncBluetooth = { viewModel.syncPendingBluetooth(selectedChat) },
                                            onTypingChanged = { isNonEmpty -> viewModel.notifyTyping(selectedChat.id, isNonEmpty) },
                                            onSendMessage = { text, type, rText, rSender, meta, delayMins ->
                                                viewModel.sendMessage(selectedChat, text, type, rText, rSender, meta, delayMins)
                                            },
                                            onSendUriAttachment = { uri, type, caption, viewOnce ->
                                                viewModel.sendUriAttachment(selectedChat, uri, type, caption, viewOnce)
                                            },
                                            onStartVoiceRecording = { viewModel.voiceAudioManager.startRecording() },
                                            onStopVoiceRecording = { discard -> viewModel.stopAndSendVoiceRecording(selectedChat, discard) },
                                            onPlayVoiceMessage = viewModel::playVoiceMessage,
                                            onDownloadMedia = viewModel::downloadMediaFile,
                                            onEditMessage = { msg, newText -> viewModel.editMessage(selectedChat, msg, newText) },
                                            onForwardMessage = { targetId, msg ->
                                                val targetThread = allChats.firstOrNull { it.id == targetId }
                                                if (targetThread != null) {
                                                    viewModel.sendMessage(
                                                        thread = targetThread,
                                                        text = "↪ Forwarded: ${msg.text}",
                                                        messageType = msg.messageType,
                                                        replyToText = null,
                                                        replyToSender = null,
                                                        mediaMeta = msg.mediaMeta
                                                    )
                                                }
                                            },
                                            onStarMessage = { msg -> viewModel.toggleStarMessage(selectedChat.id, msg) },
                                            onToggleReaction = { msg, emoji -> viewModel.toggleMessageReaction(selectedChat.id, msg, emoji) },
                                            onDeleteForMe = { msgId -> viewModel.deleteMessageForMe(selectedChat.id, msgId) },
                                            onDeleteForEveryone = { msgId -> viewModel.deleteMessageForEveryone(selectedChat.id, msgId) },
                                            onOpenViewOnce = { msgId -> viewModel.openViewOnceMessage(selectedChat.id, msgId) },
                                            onSetDisappearing = { mode -> viewModel.setDisappearingMode(selectedChat.id, mode) },
                                            onSetWallpaper = { style -> viewModel.setWallpaperStyle(selectedChat.id, style) },
                                            onToggleChatLock = { viewModel.toggleLockChat(selectedChat) },
                                            onToggleBlockPeer = {
                                                if (selectedChat.peerUid.isNotBlank()) {
                                                    if (isPeerBlocked) {
                                                        viewModel.unblockUser(selectedChat.peerUid)
                                                    } else {
                                                        viewModel.blockUser(selectedChat.peerUid, selectedChat.phone, selectedChat.title)
                                                    }
                                                }
                                            },
                                            onOpenAiAssistant = { msg ->
                                                aiTargetMessage = msg
                                                showAiSheet = true
                                            },
                                            inlineSummaryState = inlineSummaryState,
                                            suggestedRepliesState = suggestedRepliesState,
                                            onSummarizeThread = {
                                                val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
                                                aiViewModel.summarizeThreadInline(selectedChat.title, msgs)
                                            },
                                            onDismissSummary = aiViewModel::dismissInlineSummary,
                                            onGenerateSuggestions = {
                                                val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
                                                aiViewModel.generateThreadSuggestions(selectedChat.title, msgs)
                                            },
                                            onDismissSuggestions = aiViewModel::dismissSuggestedReplies,
                                            onOpenExportChat = {
                                                viewModel.resetExportState()
                                                showChatExportDialog = true
                                            },
                                            onStartVoiceCall = { startDirectOrLookupCall(selectedChat, isVideo = false) },
                                            onStartVideoCall = { startDirectOrLookupCall(selectedChat, isVideo = true) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showBluetoothSheet) {
        BluetoothMeshSheet(
            meshStatus = meshStatus,
            onDismiss = { showBluetoothSheet = false },
            onToggleOfflineMode = viewModel::toggleOfflineBluetoothMode,
            onStartScan = viewModel::startNearbyBluetoothScan,
            onStopScan = viewModel::stopNearbyBluetoothScan,
            onTogglePeerConnect = viewModel::togglePeerConnect,
            onCreateBluetoothGroup = { groupName ->
                viewModel.createGroup(
                    title = groupName,
                    description = "100m Offline Bluetooth Mesh Group",
                    chatType = "BLUETOOTH_GROUP",
                    members = emptyList(),
                    onlyAdminCanSend = false,
                    bluetoothChat = true,
                    communityName = "Nearby Mesh"
                )
            }
        )
    }

    if (showAiSheet && selectedChat != null) {
        val msgs = (messagesState as? UiState.Success)?.data ?: emptyList()
        WhatsupAiSheet(
            chatTitle = selectedChat.title,
            messages = msgs,
            selectedMessageForTranslate = aiTargetMessage,
            aiViewModel = aiViewModel,
            onInsertReply = { draft ->
                viewModel.sendMessage(selectedChat, draft)
            },
            onDismiss = {
                aiViewModel.reset()
                showAiSheet = false
            }
        )
    }

    if (showNewChatDialog) {
        var selectedCountry by remember { mutableStateOf(PhoneNumberUtils.defaultCountry) }
        var showCountryDropdown by remember { mutableStateOf(false) }
        var phoneInput by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = {
                viewModel.resetContactLookup()
                showNewChatDialog = false
            },
            icon = { Icon(Icons.Filled.PersonSearch, contentDescription = null, tint = WhatsupGreen) },
            title = { Text("Start New Whatsup Chat") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "Enter a registered mobile number to verify if they are on Whatsup.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Box {
                        OutlinedButton(
                            onClick = { showCountryDropdown = true },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("${selectedCountry.flagEmoji} ${selectedCountry.name} (${selectedCountry.dialCode})")
                        }
                        DropdownMenu(
                            expanded = showCountryDropdown,
                            onDismissRequest = { showCountryDropdown = false }
                        ) {
                            PhoneNumberUtils.supportedCountries.forEach { country ->
                                DropdownMenuItem(
                                    text = { Text("${country.flagEmoji} ${country.name} (${country.dialCode})") },
                                    onClick = {
                                        selectedCountry = country
                                        showCountryDropdown = false
                                    }
                                )
                            }
                        }
                    }

                    OutlinedTextField(
                        value = phoneInput,
                        onValueChange = { phoneInput = it.filter { c -> c.isDigit() || c == ' ' || c == '+' }.take(18) },
                        label = { Text("Phone (${selectedCountry.dialCode} ...)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        modifier = Modifier.testTag("find_contact_phone_input")
                    )

                    Button(
                        onClick = { viewModel.lookupPhoneNumber(phoneInput, selectedCountry) },
                        enabled = phoneInput.isNotBlank() && lookupState !is ContactLookupUiState.Searching,
                        colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("find_contact_search_button")
                    ) {
                        if (lookupState is ContactLookupUiState.Searching) {
                            CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Searching...", color = Color.White)
                        } else {
                            Text("Search Number", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }

                    when (val result = lookupState) {
                        is ContactLookupUiState.NotFound -> {
                            Text(
                                text = result.message,
                                color = MaterialTheme.colorScheme.error,
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        is ContactLookupUiState.Found -> {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = WhatsupGreen.copy(alpha = 0.14f)),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(result.contact.savedName, fontWeight = FontWeight.Bold)
                                        Text(
                                            PhoneNumberUtils.formatDisplay(result.contact.phoneE164),
                                            style = MaterialTheme.typography.bodySmall
                                        )
                                    }
                                    Button(
                                        onClick = {
                                            viewModel.openDirectChatWithContact(result.contact)
                                            showNewChatDialog = false
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen)
                                    ) {
                                        Text("Start Chat", color = Color.White)
                                    }
                                }
                            }
                        }
                        else -> Unit
                    }

                    if (verifiedContacts.isNotEmpty()) {
                        Text(
                            text = "Verified Contacts",
                            style = MaterialTheme.typography.labelMedium,
                            color = WhatsupGreen,
                            fontWeight = FontWeight.Bold
                        )
                        LazyColumn(modifier = Modifier.heightIn(max = 180.dp)) {
                            items(verifiedContacts, key = { it.contactUid }) { contact ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable {
                                            viewModel.openDirectChatWithContact(contact)
                                            showNewChatDialog = false
                                        }
                                        .padding(vertical = 8.dp, horizontal = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(contact.savedName, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            PhoneNumberUtils.formatDisplay(contact.phoneE164),
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Text("Chat", color = WhatsupGreen, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.resetContactLookup()
                        showNewChatDialog = false
                    }
                ) { Text("Close") }
            }
        )
    }

    if (showChatExportDialog && selectedChat != null) {
        val docsPath = remember(context) {
            ChatHistoryExporter.getLocalDocumentsDir(context).absolutePath
        }
        ExportChatHistoryDialog(
            chats = allChats,
            initialChatId = selectedChat.id,
            exportState = exportState,
            exportedFiles = exportedFiles,
            localDocumentsPath = docsPath,
            onRefreshExports = { viewModel.refreshExportedFiles(context) },
            onExport = { chatId, format -> viewModel.exportChatHistory(context, chatId, format) },
            onDeleteExport = { file -> viewModel.deleteExportedFile(context, file) },
            onDismiss = {
                viewModel.resetExportState()
                showChatExportDialog = false
            }
        )
    }
}

@Composable
private fun IncomingCallBanner(
    callerName: String,
    isVideo: Boolean,
    onAccept: () -> Unit,
    onReject: () -> Unit
) {
    Surface(
        color = WhatsupDarkGreen,
        shadowElevation = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .testTag("incoming_call_banner")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (isVideo) "Incoming Whatsup Video Call" else "Incoming Whatsup Voice Call",
                    style = MaterialTheme.typography.labelMedium,
                    color = WhatsupGreen,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = callerName.ifBlank { "Whatsup Contact" },
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            IconButton(
                onClick = onReject,
                modifier = Modifier
                    .size(44.dp)
                    .background(MissedCallRed, shape = androidx.compose.foundation.shape.CircleShape)
            ) {
                Icon(Icons.Filled.CallEnd, contentDescription = "Decline Call", tint = Color.White)
            }
            Spacer(modifier = Modifier.width(10.dp))
            IconButton(
                onClick = onAccept,
                modifier = Modifier
                    .size(44.dp)
                    .background(WhatsupGreen, shape = androidx.compose.foundation.shape.CircleShape)
            ) {
                Icon(Icons.Filled.Call, contentDescription = "Accept Call", tint = Color.White)
            }
        }
    }
}
