package com.example.ui.screens.auth

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.core.PhoneNumberUtils
import com.example.ui.components.WhatsupBrandLogo
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.AuthRateLimitPolicy
import com.example.ui.viewmodel.AuthStage
import com.example.ui.viewmodel.AuthViewModel

@Composable
fun AuthScreen(
    authViewModel: AuthViewModel,
    onRegisterProfile: suspend (displayName: String, about: String) -> Result<Unit>
) {
    val context = LocalContext.current
    val activity = context as? Activity
    val uiState by authViewModel.uiState.collectAsStateWithLifecycle()

    var showCountryPicker by remember { mutableStateOf(false) }
    var showRecoveryDialog by remember { mutableStateOf(false) }

    LaunchedEffect(uiState.stage) {
        if (uiState.stage == AuthStage.OTP_ENTRY) {
            authViewModel.startSmsAutoDetection(context)
        }
    }

    if (uiState.stage == AuthStage.OTP_ENTRY) {
        BackHandler { authViewModel.editPhoneNumberAgain() }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier.widthIn(max = 520.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(10.dp))
            WhatsupBrandLogo(size = 80.dp)
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = when (uiState.stage) {
                    AuthStage.PHONE_ENTRY -> "Verify your phone number"
                    AuthStage.OTP_ENTRY -> "Enter SMS verification code"
                    AuthStage.TWO_STEP_CHALLENGE -> "Two-Step Verification"
                    AuthStage.PROFILE_SETUP, AuthStage.READY -> "Complete your profile"
                },
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = WhatsupDarkGreen,
                textAlign = TextAlign.Center
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = when (uiState.stage) {
                    AuthStage.PHONE_ENTRY -> "Whatsup will send an SMS to verify your mobile number. Standard carrier rates may apply."
                    AuthStage.OTP_ENTRY -> "We sent a 6-digit SMS code to ${PhoneNumberUtils.formatDisplay(uiState.normalizedE164)}."
                    AuthStage.TWO_STEP_CHALLENGE -> "This number is protected by Two-Step Verification. Enter your 6-digit PIN."
                    AuthStage.PROFILE_SETUP, AuthStage.READY -> "Add your name and optional info so contacts can recognize you on Whatsup."
                },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            when (uiState.stage) {
                AuthStage.PHONE_ENTRY -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.PhoneAndroid, contentDescription = null, tint = WhatsupDarkGreen, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Mobile Number Authentication",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            // Country selector button
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surface,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp)
                                    .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                                    .clip(RoundedCornerShape(10.dp))
                                    .clickable { showCountryPicker = true }
                                    .testTag("country_selector_button")
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "${uiState.selectedCountry.flagEmoji}  ${uiState.selectedCountry.name} (${uiState.selectedCountry.dialCode})",
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Medium
                                    )
                                    Icon(Icons.Filled.ArrowDropDown, contentDescription = "Select country")
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surface,
                                    modifier = Modifier
                                        .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(10.dp))
                                        .padding(horizontal = 12.dp, vertical = 16.dp)
                                ) {
                                    Text(
                                        text = uiState.selectedCountry.dialCode,
                                        style = MaterialTheme.typography.bodyLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                OutlinedTextField(
                                    value = uiState.phoneNumberInput,
                                    onValueChange = authViewModel::updatePhoneNumber,
                                    label = { Text(uiState.selectedCountry.exampleHint) },
                                    singleLine = true,
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("phone_number_input")
                                )
                            }

                            Button(
                                onClick = { activity?.let { authViewModel.requestOtp(it, isResend = false) } },
                                enabled = !uiState.isLoading && activity != null,
                                colors = ButtonDefaults.buttonColors(containerColor = WhatsupDarkGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("send_otp_button")
                            ) {
                                if (uiState.isLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White, strokeWidth = 2.dp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Sending SMS...", color = Color.White)
                                } else {
                                    Text("Send SMS Verification Code", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }

                AuthStage.OTP_ENTRY -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Sms, contentDescription = null, tint = WhatsupDarkGreen, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "6-Digit SMS OTP",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedTextField(
                                value = uiState.otpCodeInput,
                                onValueChange = authViewModel::updateOtpCode,
                                label = { Text("Enter 6-digit code") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("otp_code_input")
                            )

                            Text(
                                text = "Attempts: ${uiState.verifyAttemptsUsed}/${AuthRateLimitPolicy.MAX_VERIFY_ATTEMPTS} • Resends: ${uiState.resendsUsed}/${AuthRateLimitPolicy.MAX_RESENDS_PER_SESSION}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                val canResend = !uiState.isLoading && uiState.resendCooldownSeconds == 0 && uiState.resendsUsed < AuthRateLimitPolicy.MAX_RESENDS_PER_SESSION
                                OutlinedButton(
                                    onClick = { activity?.let { authViewModel.requestOtp(it, isResend = true) } },
                                    enabled = canResend && activity != null,
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(48.dp)
                                        .testTag("resend_otp_button")
                                ) {
                                    Text(
                                        text = if (uiState.resendCooldownSeconds > 0) {
                                            "Resend (${uiState.resendCooldownSeconds}s)"
                                        } else {
                                            "Resend"
                                        }
                                    )
                                }
                                Button(
                                    onClick = authViewModel::verifyEnteredOtp,
                                    enabled = !uiState.isLoading && uiState.otpCodeInput.length == 6,
                                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupDarkGreen),
                                    modifier = Modifier
                                        .weight(1.3f)
                                        .height(48.dp)
                                        .testTag("verify_otp_button")
                                ) {
                                    if (uiState.isLoading) {
                                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                    } else {
                                        Text("Verify OTP", color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }

                            TextButton(
                                onClick = authViewModel::editPhoneNumberAgain,
                                modifier = Modifier.align(Alignment.CenterHorizontally)
                            ) {
                                Text("Wrong number? Edit phone number")
                            }
                        }
                    }
                }

                AuthStage.TWO_STEP_CHALLENGE -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Key, contentDescription = null, tint = WhatsupDarkGreen, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Enter 6-Digit Security PIN", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            }

                            OutlinedTextField(
                                value = uiState.twoStepPinInput,
                                onValueChange = authViewModel::updateTwoStepPinInput,
                                label = { Text("Two-Step PIN (6 digits)") },
                                visualTransformation = PasswordVisualTransformation(),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("two_step_challenge_input")
                            )

                            Button(
                                onClick = authViewModel::verifyTwoStepChallenge,
                                enabled = !uiState.isLoading && uiState.twoStepPinInput.length == 6,
                                colors = ButtonDefaults.buttonColors(containerColor = WhatsupDarkGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("two_step_verify_button")
                            ) {
                                if (uiState.isLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                } else {
                                    Text("Unlock Account", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                TextButton(onClick = { showRecoveryDialog = true }) {
                                    Text("Forgot PIN?")
                                }
                                TextButton(onClick = { authViewModel.signOut(context) }) {
                                    Text("Use different number")
                                }
                            }
                        }
                    }
                }

                AuthStage.PROFILE_SETUP, AuthStage.READY -> {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.Person, contentDescription = null, tint = WhatsupDarkGreen, modifier = Modifier.size(20.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Profile Details", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                            }

                            OutlinedTextField(
                                value = uiState.profileNameInput,
                                onValueChange = authViewModel::updateProfileNameInput,
                                label = { Text("Your Name") },
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("profile_setup_name_input")
                            )

                            OutlinedTextField(
                                value = uiState.profileAboutInput,
                                onValueChange = authViewModel::updateProfileAboutInput,
                                label = { Text("About") },
                                maxLines = 2,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("profile_setup_about_input")
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text("Enable Two-Step Verification PIN", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                                    Text("Recommended when signing in on a new device", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                                Switch(
                                    checked = uiState.showPinSetupInOnboarding,
                                    onCheckedChange = authViewModel::toggleOnboardingTwoStep,
                                    colors = SwitchDefaults.colors(checkedTrackColor = WhatsupGreen)
                                )
                            }

                            if (uiState.showPinSetupInOnboarding) {
                                OutlinedTextField(
                                    value = uiState.twoStepPinInput,
                                    onValueChange = authViewModel::updateTwoStepPinInput,
                                    label = { Text("Create 6-digit PIN") },
                                    visualTransformation = PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = uiState.twoStepConfirmInput,
                                    onValueChange = authViewModel::updateTwoStepConfirmInput,
                                    label = { Text("Confirm 6-digit PIN") },
                                    visualTransformation = PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                OutlinedTextField(
                                    value = uiState.twoStepHintInput,
                                    onValueChange = authViewModel::updateTwoStepHintInput,
                                    label = { Text("Recovery Hint / Keyword (for PIN reset)") },
                                    singleLine = true,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }

                            Button(
                                onClick = { authViewModel.completeOnboardingProfile(onRegisterProfile) },
                                enabled = !uiState.isLoading && uiState.profileNameInput.isNotBlank(),
                                colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(50.dp)
                                    .testTag("complete_profile_button")
                            ) {
                                if (uiState.isLoading) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.White, strokeWidth = 2.dp)
                                } else {
                                    Text("Continue to Whatsup", color = Color(0xFF002B14), fontWeight = FontWeight.Bold)
                                }
                            }

                            if (activity != null) {
                                OutlinedButton(
                                    onClick = { authViewModel.linkGoogleAccountOptional(activity) },
                                    enabled = !uiState.isLoading,
                                    modifier = Modifier.fillMaxWidth().height(46.dp)
                                ) {
                                    Text("Link Google Account (Optional)")
                                }
                            }
                        }
                    }
                }
            }

            if (uiState.infoBanner != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    color = WhatsupGreen.copy(alpha = 0.14f),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = uiState.infoBanner!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = WhatsupDarkGreen,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            if (uiState.errorMessage != null) {
                Spacer(modifier = Modifier.height(12.dp))
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = uiState.errorMessage!!,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onErrorContainer,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Filled.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Real ECDH + AES-256 E2EE • ", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Icon(Icons.Filled.BluetoothConnected, contentDescription = null, tint = BluetoothBlue, modifier = Modifier.size(14.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("100m Offline Bluetooth Ready", style = MaterialTheme.typography.labelSmall, color = BluetoothBlue)
            }
        }
    }

    if (showCountryPicker) {
        AlertDialog(
            onDismissRequest = { showCountryPicker = false },
            title = { Text("Select Country Code") },
            text = {
                LazyColumn(modifier = Modifier.heightIn(max = 380.dp)) {
                    items(PhoneNumberUtils.supportedCountries) { country ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    authViewModel.selectCountry(country)
                                    showCountryPicker = false
                                }
                                .padding(vertical = 12.dp, horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("${country.flagEmoji}  ${country.name}", style = MaterialTheme.typography.bodyLarge)
                            Text(country.dialCode, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = WhatsupDarkGreen)
                        }
                        HorizontalDivider()
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCountryPicker = false }) { Text("Close") }
            }
        )
    }

    if (showRecoveryDialog) {
        var hintInput by remember { mutableStateOf("") }
        var newPin by remember { mutableStateOf("") }
        var confirmPin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showRecoveryDialog = false },
            title = { Text("Recover Two-Step PIN") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        "Enter the recovery hint you saved when configuring Two-Step Verification.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = hintInput,
                        onValueChange = { hintInput = it },
                        label = { Text("Recovery Hint") },
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = newPin,
                        onValueChange = { newPin = it.filter { c -> c.isDigit() }.take(6) },
                        label = { Text("New 6-digit PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = confirmPin,
                        onValueChange = { confirmPin = it.filter { c -> c.isDigit() }.take(6) },
                        label = { Text("Confirm New PIN") },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        singleLine = true
                    )
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    authViewModel.recoverTwoStepPin(hintInput, newPin, confirmPin)
                    showRecoveryDialog = false
                }) { Text("Reset PIN") }
            },
            dismissButton = {
                TextButton(onClick = { showRecoveryDialog = false }) { Text("Cancel") }
            }
        )
    }
}
