package com.example.ui.screens.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.DownloadDone
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.core.ChatHistoryExporter
import com.example.core.ExportFormat
import com.example.core.ExportedChatFile
import com.example.data.model.ChatThread
import com.example.ui.theme.BluetoothBlue
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import com.example.ui.viewmodel.ExportUiState
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ExportChatHistoryDialog(
    chats: List<ChatThread>,
    initialChatId: String? = null,
    exportState: ExportUiState,
    exportedFiles: List<ExportedChatFile>,
    localDocumentsPath: String,
    onRefreshExports: () -> Unit,
    onExport: (chatId: String?, format: ExportFormat) -> Unit,
    onDeleteExport: (ExportedChatFile) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedChatId by remember(initialChatId) { mutableStateOf(initialChatId) }
    var selectedFormat by remember { mutableStateOf(ExportFormat.JSON) }
    var previewFile by remember { mutableStateOf<ExportedChatFile?>(null) }

    LaunchedEffect(Unit) {
        onRefreshExports()
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(
                imageVector = Icons.Filled.FolderOpen,
                contentDescription = "Export Chat History",
                tint = WhatsupGreen
            )
        },
        title = {
            Text(
                text = "Export Chat History",
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "Save chat history directly to the app's local Documents folder as JSON or TXT.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                // Scope Selector (All Chats or specific chat)
                Text(
                    text = "Conversation Scope",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = WhatsupGreen
                )
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FilterChip(
                        selected = selectedChatId == null,
                        onClick = { selectedChatId = null },
                        label = { Text("All Chats (${chats.size})") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = WhatsupGreen.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier.testTag("export_scope_all_chats")
                    )
                    chats.forEach { thread ->
                        FilterChip(
                            selected = selectedChatId == thread.id,
                            onClick = { selectedChatId = thread.id },
                            label = {
                                Text(
                                    text = thread.title,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WhatsupGreen.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.testTag("export_scope_chat_${thread.id}")
                        )
                    }
                }

                // File Format Selector
                Text(
                    text = "File Format",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = WhatsupGreen
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ExportFormat.entries.forEach { format ->
                        val selected = selectedFormat == format
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = if (selected) WhatsupGreen.copy(alpha = 0.14f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            border = BorderStroke(
                                width = if (selected) 1.5.dp else 1.dp,
                                color = if (selected) WhatsupGreen else MaterialTheme.colorScheme.outlineVariant
                            ),
                            modifier = Modifier
                                .weight(1f)
                                .clickable { selectedFormat = format }
                                .testTag("export_format_${format.extension}")
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (format == ExportFormat.JSON) Icons.Filled.Code else Icons.Filled.Description,
                                        contentDescription = format.label,
                                        tint = if (selected) WhatsupDarkGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = format.label,
                                        style = MaterialTheme.typography.labelLarge,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = format.description,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 2
                                )
                            }
                        }
                    }
                }

                // Destination directory hint
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        Text(
                            text = "Local Documents Directory",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = BluetoothBlue
                        )
                        Text(
                            text = localDocumentsPath,
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Export Status Banner
                when (exportState) {
                    is ExportUiState.Exporting -> {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = WhatsupGreen
                            )
                            Text(
                                text = "Writing ${selectedFormat.extension.uppercase()} export to Documents...",
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    is ExportUiState.Success -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = WhatsupGreen.copy(alpha = 0.14f),
                            border = BorderStroke(1.dp, WhatsupGreen.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("export_success_banner")
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.CheckCircle,
                                    contentDescription = "Exported",
                                    tint = WhatsupDarkGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Saved: ${exportState.file.name}",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${formatFileSize(exportState.file.sizeBytes)} • Stored in Documents",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                    is ExportUiState.Error -> {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.errorContainer,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = exportState.message,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                    ExportUiState.Idle -> Unit
                }

                // Saved Exports List
                if (exportedFiles.isNotEmpty()) {
                    HorizontalDivider()
                    Text(
                        text = "Saved in Local Documents (${exportedFiles.size})",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = WhatsupGreen
                    )
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        exportedFiles.take(8).forEachIndexed { idx, file ->
                            val dateStr = remember(file.lastModifiedMillis) {
                                SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())
                                    .format(Date(file.lastModifiedMillis))
                            }
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("exported_file_item_$idx")
                            ) {
                                Row(
                                    modifier = Modifier.padding(start = 10.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = if (file.format == ExportFormat.JSON) Icons.Filled.Code else Icons.Filled.Description,
                                        contentDescription = file.format.label,
                                        tint = if (file.format == ExportFormat.JSON) BluetoothBlue else WhatsupDarkGreen,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = file.name,
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.SemiBold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            text = "${file.format.extension.uppercase()} • ${formatFileSize(file.sizeBytes)} • $dateStr",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    IconButton(
                                        onClick = { previewFile = file },
                                        modifier = Modifier.testTag("preview_export_button_$idx")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.Visibility,
                                            contentDescription = "Preview exported file",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                    IconButton(
                                        onClick = { onDeleteExport(file) },
                                        modifier = Modifier.testTag("delete_export_button_$idx")
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.DeleteOutline,
                                            contentDescription = "Delete exported file",
                                            tint = MaterialTheme.colorScheme.error,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onExport(selectedChatId, selectedFormat) },
                enabled = exportState !is ExportUiState.Exporting,
                colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
                modifier = Modifier.testTag("confirm_export_chat_button")
            ) {
                Icon(
                    imageVector = Icons.Filled.DownloadDone,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Export ${selectedFormat.extension.uppercase()}",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("close_export_dialog_button")
            ) {
                Text("Close")
            }
        }
    )

    if (previewFile != null) {
        val previewContent = remember(previewFile!!.absolutePath) {
            ChatHistoryExporter.readExportedFilePreview(previewFile!!.absolutePath)
        }
        AlertDialog(
            onDismissRequest = { previewFile = null },
            title = {
                Text(
                    text = previewFile!!.name,
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            },
            text = {
                Text(
                    text = previewContent,
                    style = MaterialTheme.typography.bodySmall,
                    fontFamily = FontFamily.Monospace,
                    modifier = Modifier
                        .heightIn(max = 360.dp)
                        .verticalScroll(rememberScrollState())
                )
            },
            confirmButton = {
                TextButton(onClick = { previewFile = null }) {
                    Text("Done")
                }
            }
        )
    }
}

private fun formatFileSize(bytes: Long): String {
    return when {
        bytes < 1024L -> "$bytes B"
        bytes < 1024L * 1024L -> "${(bytes / 1024.0).let { String.format(Locale.US, "%.1f", it) }} KB"
        else -> "${(bytes / (1024.0 * 1024.0)).let { String.format(Locale.US, "%.2f", it) }} MB"
    }
}
