package com.example.ui.screens.updates

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.StatusUpdate
import com.example.data.model.StatusViewer
import com.example.data.model.UiState
import com.example.data.model.VerifiedContact
import com.example.ui.theme.WhatsupDarkGreen
import com.example.ui.theme.WhatsupGreen
import kotlinx.coroutines.flow.Flow

@Composable
fun UpdatesScreen(
    statusesState: UiState<List<StatusUpdate>>,
    currentUserId: String,
    myDisplayName: String,
    verifiedContacts: List<VerifiedContact>,
    onPostStatus: (
        caption: String,
        statusType: String,
        bgColorHex: Long,
        mediaUri: Uri?,
        privacyMode: String,
        selectedTargetUids: List<String>
    ) -> Unit,
    onMarkViewed: (StatusUpdate) -> Unit,
    onObserveViewers: (String) -> Flow<List<StatusViewer>>,
    onDeleteStatus: (String) -> Unit,
    onReplyToStatus: (StatusUpdate, String) -> Unit
) {
    var showCreateTextStatus by remember { mutableStateOf(false) }
    var pendingMediaUri by remember { mutableStateOf<Uri?>(null) }
    var pendingStatusType by remember { mutableStateOf("TEXT") }
    var activeViewerList by remember { mutableStateOf<List<StatusUpdate>>(emptyList()) }
    var activeViewerStartIndex by remember { mutableStateOf<Int?>(null) }
    var captionInput by remember { mutableStateOf("") }
    var privacyMode by remember { mutableStateOf("ALL_CONTACTS") }
    val selectedUids = remember { mutableStateListOf<String>() }

    val statusPhotoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            pendingMediaUri = uri
            pendingStatusType = "PHOTO"
            captionInput = ""
            showCreateTextStatus = true
        }
    }

    when (statusesState) {
        is UiState.Loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = WhatsupGreen)
        }
        is UiState.Error -> Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text(statusesState.message, color = MaterialTheme.colorScheme.error)
        }
        is UiState.Success -> {
            val stories = statusesState.data
            val myStories = stories.filter { it.userId == currentUserId }
            val otherStories = stories.filter { it.userId != currentUserId }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item(key = "status_header") {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Status (24h)",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                        Row {
                            IconButton(
                                onClick = {
                                    pendingMediaUri = null
                                    pendingStatusType = "TEXT"
                                    showCreateTextStatus = true
                                },
                                modifier = Modifier.testTag("add_text_status_button")
                            ) {
                                Icon(Icons.Filled.Edit, contentDescription = "Text Status", tint = WhatsupDarkGreen)
                            }
                            IconButton(
                                onClick = {
                                    statusPhotoPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo))
                                },
                                modifier = Modifier.testTag("add_media_status_button")
                            ) {
                                Icon(Icons.Filled.PhotoCamera, contentDescription = "Photo/Video Status", tint = WhatsupDarkGreen)
                            }
                        }
                    }
                }

                item(key = "my_status") {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                if (myStories.isNotEmpty()) {
                                    activeViewerList = myStories
                                    activeViewerStartIndex = 0
                                } else {
                                    pendingMediaUri = null
                                    pendingStatusType = "TEXT"
                                    showCreateTextStatus = true
                                }
                            }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(modifier = Modifier.size(54.dp)) {
                            Box(
                                modifier = Modifier
                                    .size(52.dp)
                                    .clip(CircleShape)
                                    .background(WhatsupDarkGreen),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = myDisplayName.ifBlank { "W" }.take(1).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .size(22.dp)
                                    .align(Alignment.BottomEnd)
                                    .clip(CircleShape)
                                    .background(WhatsupGreen)
                                    .border(2.dp, MaterialTheme.colorScheme.surface, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Filled.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            }
                        }
                        Spacer(modifier = Modifier.width(14.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("My status", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            Text(
                                text = if (myStories.isEmpty()) {
                                    "Tap to add a 24h text, photo or video update"
                                } else {
                                    "${myStories.size} active update(s) • Tap to view or check viewers"
                                },
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                item(key = "recent_updates_label") {
                    Text(
                        text = "Recent updates",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                if (otherStories.isEmpty()) {
                    item(key = "no_peer_statuses") {
                        Text(
                            text = "No recent status updates from your contacts.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 8.dp)
                        )
                    }
                } else {
                    items(otherStories, key = { it.id }) { status ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .clickable {
                                    val idx = otherStories.indexOfFirst { it.id == status.id }.coerceAtLeast(0)
                                    activeViewerList = otherStories
                                    activeViewerStartIndex = idx
                                }
                                .padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(54.dp)
                                    .border(
                                        width = 2.5.dp,
                                        color = if (status.viewed) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f) else WhatsupGreen,
                                        shape = CircleShape
                                    )
                                    .padding(4.dp)
                                    .clip(CircleShape)
                                    .background(Color(status.bgColorHex)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = status.authorName.ifBlank { "W" }.take(1).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Spacer(modifier = Modifier.width(14.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(status.authorName, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                                Text(
                                    text = "${status.timeLabel} • ${status.statusType}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Filled.Visibility,
                                    contentDescription = "Views",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(status.viewedByCount.toString(), style = MaterialTheme.typography.labelSmall)
                            }
                        }
                    }
                }

                item(key = "updates_bottom_pad") { Spacer(modifier = Modifier.height(88.dp)) }
            }
        }
    }

    if (showCreateTextStatus) {
        AlertDialog(
            onDismissRequest = { showCreateTextStatus = false },
            title = { Text(if (pendingMediaUri != null) "Share Photo/Video Status (24h)" else "New 24-Hour Status") },
            text = {
                LazyColumn(
                    modifier = Modifier.heightIn(max = 380.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        OutlinedTextField(
                            value = captionInput,
                            onValueChange = { captionInput = it },
                            label = { Text(if (pendingMediaUri != null) "Add caption..." else "Share a status update...") },
                            maxLines = 4,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("status_caption_input")
                        )
                    }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Lock, contentDescription = null, modifier = Modifier.size(16.dp), tint = WhatsupGreen)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Status Privacy", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(
                                "ALL_CONTACTS" to "All Contacts",
                                "EXCEPT" to "Except...",
                                "ONLY_SHARE_WITH" to "Only With..."
                            ).forEach { (mode, label) ->
                                FilterChip(
                                    selected = privacyMode == mode,
                                    onClick = { privacyMode = mode },
                                    label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }
                    if (privacyMode != "ALL_CONTACTS" && verifiedContacts.isNotEmpty()) {
                        items(verifiedContacts, key = { it.contactUid }) { contact ->
                            val checked = contact.contactUid in selectedUids
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        if (checked) selectedUids.remove(contact.contactUid) else selectedUids.add(contact.contactUid)
                                    },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = checked,
                                    onCheckedChange = {
                                        if (checked) selectedUids.remove(contact.contactUid) else selectedUids.add(contact.contactUid)
                                    }
                                )
                                Text(contact.savedName, style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val finalCaption = captionInput.trim().ifBlank { if (pendingMediaUri != null) "Photo Update" else "" }
                        if (finalCaption.isNotEmpty() || pendingMediaUri != null) {
                            onPostStatus(
                                finalCaption,
                                pendingStatusType,
                                0xFF128C7EL,
                                pendingMediaUri,
                                privacyMode,
                                selectedUids.toList()
                            )
                            captionInput = ""
                            pendingMediaUri = null
                            showCreateTextStatus = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = WhatsupGreen),
                    modifier = Modifier.testTag("post_status_button")
                ) { Text("Post Status") }
            },
            dismissButton = {
                TextButton(onClick = {
                    pendingMediaUri = null
                    showCreateTextStatus = false
                }) { Text("Cancel") }
            }
        )
    }

    if (activeViewerStartIndex != null && activeViewerList.isNotEmpty()) {
        StatusStoryViewer(
            stories = activeViewerList,
            initialIndex = activeViewerStartIndex!!,
            currentUserId = currentUserId,
            onMarkViewed = onMarkViewed,
            onObserveViewers = onObserveViewers,
            onDeleteStatus = { id ->
                onDeleteStatus(id)
                activeViewerStartIndex = null
                activeViewerList = emptyList()
            },
            onReplyToStatus = onReplyToStatus,
            onDismiss = {
                activeViewerStartIndex = null
                activeViewerList = emptyList()
            }
        )
    }
}
