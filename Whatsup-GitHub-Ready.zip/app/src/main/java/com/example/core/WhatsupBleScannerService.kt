package com.example.core

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.AdvertiseCallback
import android.bluetooth.le.AdvertiseData
import android.bluetooth.le.AdvertiseSettings
import android.bluetooth.le.BluetoothLeAdvertiser
import android.bluetooth.le.BluetoothLeScanner
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.ParcelUuid
import android.util.Log
import androidx.core.content.ContextCompat
import com.example.data.model.NearbyBluetoothPeer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

private const val TAG = "WhatsupBleService"

data class BleScanSnapshot(
    val scanning: Boolean = false,
    val advertising: Boolean = false,
    val bluetoothEnabled: Boolean = false,
    val serviceUuid: String = WhatsupBleScannerService.WHATSUP_MESH_SERVICE_UUID.toString(),
    val discoveredPeers: List<NearbyBluetoothPeer> = emptyList(),
    val whatsupPeerDetected: Boolean = false,
    val statusDetail: String = "Continuous Whatsup BLE Scanner standby"
)

/**
 * Native Android BLE Scanner & Advertiser Service Layer targeting Whatsup's
 * dedicated Service UUID (equivalent to Flutter Blue Plus continuous UUID scan).
 *
 * Constantly monitors nearby devices broadcasting [WHATSUP_MESH_SERVICE_UUID]
 * so the mesh engine can automatically trigger Offline Chat Mode when peers are in range.
 */
class WhatsupBleScannerService(private val context: Context) {

    companion object {
        // Dedicated 128-bit Whatsup Mesh Service UUID ("WHATSUPMESH")
        val WHATSUP_MESH_SERVICE_UUID: UUID =
            UUID.fromString("a7e30001-5748-4154-5355-504d45534801")
        val WHATSUP_MESH_PARCEL_UUID: ParcelUuid = ParcelUuid(WHATSUP_MESH_SERVICE_UUID)

        private const val PEER_STALE_TIMEOUT_MS = 25_000L
        private const val SCAN_DUTY_CYCLE_REFRESH_MS = 12 * 60 * 1000L
    }

    private data class TrackedPeer(
        val peer: NearbyBluetoothPeer,
        val lastSeenMillis: Long
    )

    private val bluetoothManager =
        context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    private val bluetoothAdapter: BluetoothAdapter?
        get() = bluetoothManager?.adapter

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val trackedPeers = ConcurrentHashMap<String, TrackedPeer>()

    private val _snapshot = MutableStateFlow(
        BleScanSnapshot(
            bluetoothEnabled = bluetoothAdapter?.isEnabled == true
        )
    )
    val snapshot: StateFlow<BleScanSnapshot> = _snapshot.asStateFlow()

    private var activeScanCallback: ScanCallback? = null
    private var activeAdvertiseCallback: AdvertiseCallback? = null
    private var maintenanceJob: Job? = null
    private var continuousEnabled = false

    fun hasScanPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_SCAN
            ) == PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) == PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun hasAdvertisePermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.BLUETOOTH_ADVERTISE
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun isBluetoothEnabled(): Boolean = bluetoothAdapter?.isEnabled == true

    /**
     * Starts continuous BLE scanning filtered for Whatsup's Service UUID.
     * Automatically cycles scans to avoid OS background scan timeouts and prunes stale peers.
     */
    @SuppressLint("MissingPermission")
    fun startContinuousScan() {
        continuousEnabled = true
        val btOn = isBluetoothEnabled()

        if (!btOn) {
            _snapshot.value = _snapshot.value.copy(
                scanning = false,
                bluetoothEnabled = false,
                statusDetail = "Bluetooth radio off • Continuous Whatsup UUID scan waiting"
            )
            return
        }

        if (!hasScanPermission()) {
            _snapshot.value = _snapshot.value.copy(
                scanning = false,
                bluetoothEnabled = true,
                statusDetail = "Grant Bluetooth Scan permission for auto Whatsup UUID discovery"
            )
            return
        }

        val scanner: BluetoothLeScanner? = bluetoothAdapter?.bluetoothLeScanner
        if (scanner == null) {
            _snapshot.value = _snapshot.value.copy(
                scanning = false,
                bluetoothEnabled = true,
                statusDetail = "BLE scanner unavailable on this hardware"
            )
            return
        }

        startHardwareScan(scanner)
        ensureMaintenanceLoop()
    }

    @SuppressLint("MissingPermission")
    private fun startHardwareScan(scanner: BluetoothLeScanner) {
        stopHardwareScanOnly()

        val filter = ScanFilter.Builder()
            .setServiceUuid(WHATSUP_MESH_PARCEL_UUID)
            .build()

        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_BALANCED)
            .build()

        val callback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                handleScanResult(result)
            }

            override fun onBatchScanResults(results: MutableList<ScanResult>) {
                results.forEach { handleScanResult(it) }
            }

            override fun onScanFailed(errorCode: Int) {
                Log.w(TAG, "Whatsup BLE UUID scan failed with code=$errorCode")
                _snapshot.value = _snapshot.value.copy(
                    scanning = false,
                    statusDetail = "Whatsup BLE scan error ($errorCode)"
                )
            }
        }

        activeScanCallback = callback
        try {
            scanner.startScan(listOf(filter), settings, callback)
            _snapshot.value = _snapshot.value.copy(
                scanning = true,
                bluetoothEnabled = true,
                statusDetail = "Constantly scanning Whatsup UUID (${WHATSUP_MESH_SERVICE_UUID.toString().take(8)}...)"
            )
        } catch (e: Exception) {
            Log.w(TAG, "Unable to start Whatsup BLE UUID scan: ${e.message}")
            activeScanCallback = null
            _snapshot.value = _snapshot.value.copy(
                scanning = false,
                statusDetail = "BLE scan unavailable: ${e.localizedMessage ?: "error"}"
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun handleScanResult(result: ScanResult) {
        val device = result.device ?: return
        val address = device.address ?: return
        val advertisedUuids = result.scanRecord?.serviceUuids.orEmpty()
        if (advertisedUuids.isNotEmpty() && WHATSUP_MESH_PARCEL_UUID !in advertisedUuids) {
            return
        }

        val name = try {
            device.name ?: result.scanRecord?.deviceName ?: "Whatsup Peer (${address.takeLast(5)})"
        } catch (_: SecurityException) {
            result.scanRecord?.deviceName ?: "Whatsup Peer (${address.takeLast(5)})"
        }

        val rssi = result.rssi
        val approxMeters = when {
            rssi >= -55 -> 3
            rssi >= -70 -> 14
            rssi >= -85 -> 45
            else -> 88
        }
        val bars = when {
            rssi >= -60 -> 4
            rssi >= -75 -> 3
            rssi >= -88 -> 2
            else -> 1
        }

        val existingConnected = trackedPeers[address]?.peer?.connected ?: false
        val peer = NearbyBluetoothPeer(
            peerId = address,
            name = name,
            phoneHint = "Whatsup UUID • BLE",
            distanceMeters = approxMeters,
            transport = "Bluetooth LE",
            signalBars = bars,
            connected = existingConnected
        )
        trackedPeers[address] = TrackedPeer(peer = peer, lastSeenMillis = System.currentTimeMillis())
        publishPeerSnapshot()
    }

    private fun ensureMaintenanceLoop() {
        if (maintenanceJob?.isActive == true) return
        maintenanceJob = serviceScope.launch {
            var lastRefreshMillis = System.currentTimeMillis()
            while (isActive && continuousEnabled) {
                delay(5_000L)
                pruneStalePeers()
                val now = System.currentTimeMillis()
                if (now - lastRefreshMillis >= SCAN_DUTY_CYCLE_REFRESH_MS) {
                    lastRefreshMillis = now
                    val scanner = bluetoothAdapter?.bluetoothLeScanner
                    if (isBluetoothEnabled() && hasScanPermission() && scanner != null) {
                        startHardwareScan(scanner)
                    }
                }
            }
        }
    }

    private fun pruneStalePeers() {
        val cutoff = System.currentTimeMillis() - PEER_STALE_TIMEOUT_MS
        var removed = false
        val iter = trackedPeers.entries.iterator()
        while (iter.hasNext()) {
            val entry = iter.next()
            if (entry.value.lastSeenMillis < cutoff) {
                iter.remove()
                removed = true
            }
        }
        if (removed) {
            publishPeerSnapshot()
        }
    }

    private fun publishPeerSnapshot() {
        val peers = trackedPeers.values
            .sortedBy { it.peer.distanceMeters }
            .map { it.peer }
        _snapshot.value = _snapshot.value.copy(
            discoveredPeers = peers,
            whatsupPeerDetected = peers.isNotEmpty(),
            bluetoothEnabled = isBluetoothEnabled()
        )
    }

    @SuppressLint("MissingPermission")
    fun startAdvertisingWhatsupService() {
        if (!isBluetoothEnabled() || !hasAdvertisePermission()) return
        val advertiser: BluetoothLeAdvertiser = bluetoothAdapter?.bluetoothLeAdvertiser ?: return
        stopAdvertisingWhatsupService()

        val settings = AdvertiseSettings.Builder()
            .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
            .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
            .setConnectable(true)
            .build()

        val data = AdvertiseData.Builder()
            .setIncludeDeviceName(false)
            .addServiceUuid(WHATSUP_MESH_PARCEL_UUID)
            .build()

        val callback = object : AdvertiseCallback() {
            override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) {
                _snapshot.value = _snapshot.value.copy(advertising = true)
            }

            override fun onStartFailure(errorCode: Int) {
                Log.w(TAG, "Whatsup BLE advertise failed: $errorCode")
                _snapshot.value = _snapshot.value.copy(advertising = false)
            }
        }
        activeAdvertiseCallback = callback
        try {
            advertiser.startAdvertising(settings, data, callback)
        } catch (e: Exception) {
            Log.w(TAG, "BLE advertise error: ${e.message}")
            activeAdvertiseCallback = null
        }
    }

    @SuppressLint("MissingPermission")
    fun stopAdvertisingWhatsupService() {
        val cb = activeAdvertiseCallback ?: return
        try {
            if (hasAdvertisePermission()) {
                bluetoothAdapter?.bluetoothLeAdvertiser?.stopAdvertising(cb)
            }
        } catch (_: Exception) {
        }
        activeAdvertiseCallback = null
        _snapshot.value = _snapshot.value.copy(advertising = false)
    }

    fun togglePeerConnected(peerId: String) {
        val current = trackedPeers[peerId] ?: return
        trackedPeers[peerId] = current.copy(
            peer = current.peer.copy(connected = !current.peer.connected)
        )
        publishPeerSnapshot()
    }

    fun stopScan() {
        continuousEnabled = false
        maintenanceJob?.cancel()
        maintenanceJob = null
        stopHardwareScanOnly()
        _snapshot.value = _snapshot.value.copy(
            scanning = false,
            statusDetail = "Whatsup BLE UUID scan paused"
        )
    }

    @SuppressLint("MissingPermission")
    private fun stopHardwareScanOnly() {
        val cb = activeScanCallback ?: return
        try {
            if (hasScanPermission()) {
                bluetoothAdapter?.bluetoothLeScanner?.stopScan(cb)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping Whatsup BLE scan: ${e.message}")
        }
        activeScanCallback = null
    }

    fun release() {
        stopScan()
        stopAdvertisingWhatsupService()
        serviceScope.cancel()
    }
}
