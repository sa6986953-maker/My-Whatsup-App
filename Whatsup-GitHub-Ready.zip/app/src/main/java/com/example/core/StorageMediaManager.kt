package com.example.core

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import com.example.core.crypto.WhatsupCryptoManager
import com.google.firebase.Firebase
import com.google.firebase.storage.FirebaseStorage
import com.google.firebase.storage.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

data class UploadedEncryptedMedia(
    val storagePath: String,
    val fileKeyBase64: String,
    val fileName: String,
    val mimeType: String,
    val byteSize: Long
)

data class UploadedPublicMedia(
    val storagePath: String,
    val downloadUrl: String
)

class StorageMediaManager(
    private val context: Context,
    private val storage: FirebaseStorage = Firebase.storage
) {
    companion object {
        // Guardrail for in-memory AES-GCM encryption buffer on device (~25MB)
        const val MAX_ENCRYPTED_IN_MEMORY_BYTES = 25L * 1024L * 1024L
    }

    suspend fun uploadEncryptedUriMedia(
        conversationId: String,
        uri: Uri,
        fallbackName: String = "media.bin"
    ): Result<UploadedEncryptedMedia> = withContext(Dispatchers.IO) {
        try {
            val resolver = context.contentResolver
            val fileName = resolveFileName(uri) ?: fallbackName
            val mimeType = resolver.getType(uri) ?: "application/octet-stream"
            val rawBytes = resolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@withContext Result.failure(IllegalStateException("Unable to read selected file"))

            if (rawBytes.size.toLong() > MAX_ENCRYPTED_IN_MEMORY_BYTES) {
                return@withContext Result.failure(
                    IllegalArgumentException("File exceeds 25 MB encrypted upload limit (${rawBytes.size / (1024 * 1024)} MB)")
                )
            }
            uploadEncryptedBytes(conversationId, rawBytes, fileName, mimeType)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun uploadEncryptedFile(
        conversationId: String,
        file: File,
        mimeType: String = "audio/mp4"
    ): Result<UploadedEncryptedMedia> = withContext(Dispatchers.IO) {
        try {
            val bytes = file.readBytes()
            uploadEncryptedBytes(conversationId, bytes, file.name, mimeType)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun uploadEncryptedBytes(
        conversationId: String,
        rawBytes: ByteArray,
        fileName: String,
        mimeType: String
    ): Result<UploadedEncryptedMedia> = withContext(Dispatchers.IO) {
        try {
            val (encryptedBlob, fileKeyB64) = WhatsupCryptoManager.encryptRawBytesWithNewKey(rawBytes)
            val objectId = UUID.randomUUID().toString().replace("-", "")
            val storagePath = "conversations/$conversationId/media/$objectId.enc"
            val ref = storage.reference.child(storagePath)
            ref.putBytes(encryptedBlob).await()
            Result.success(
                UploadedEncryptedMedia(
                    storagePath = storagePath,
                    fileKeyBase64 = fileKeyB64,
                    fileName = fileName,
                    mimeType = mimeType,
                    byteSize = rawBytes.size.toLong()
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun downloadAndDecryptMedia(
        storagePath: String,
        fileKeyBase64: String,
        targetFileName: String
    ): Result<File> = withContext(Dispatchers.IO) {
        try {
            val cacheDir = File(context.cacheDir, "decrypted_media").apply { mkdirs() }
            val safeName = targetFileName.replace(Regex("[^a-zA-Z0-9._-]"), "_")
            val localFile = File(cacheDir, "${storagePath.hashCode().toUInt()}_$safeName")
            if (localFile.exists() && localFile.length() > 0L) {
                return@withContext Result.success(localFile)
            }
            val encryptedBytes = storage.reference.child(storagePath)
                .getBytes(MAX_ENCRYPTED_IN_MEMORY_BYTES + 1024L * 1024L)
                .await()
            val plainBytes = WhatsupCryptoManager.decryptRawBytesWithKey(encryptedBytes, fileKeyBase64)
            localFile.writeBytes(plainBytes)
            Result.success(localFile)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun uploadUserAvatarOrStatusMedia(
        storagePath: String,
        uri: Uri
    ): Result<UploadedPublicMedia> = withContext(Dispatchers.IO) {
        try {
            val ref = storage.reference.child(storagePath)
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                ?: return@withContext Result.failure(IllegalStateException("Cannot open selected image/video"))
            if (bytes.size.toLong() > MAX_ENCRYPTED_IN_MEMORY_BYTES) {
                return@withContext Result.failure(IllegalArgumentException("Media too large (max 25 MB)"))
            }
            ref.putBytes(bytes).await()
            val url = ref.downloadUrl.await().toString()
            Result.success(UploadedPublicMedia(storagePath = storagePath, downloadUrl = url))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun resolveFileName(uri: Uri): String? {
        return try {
            context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) c.getString(idx) else null
                } else null
            }
        } catch (_: Exception) {
            uri.lastPathSegment
        }
    }

    fun calculateLocalMediaCacheBytes(): Long {
        val cacheDirs = listOf(
            File(context.cacheDir, "decrypted_media"),
            File(context.cacheDir, "voice_notes")
        )
        return cacheDirs.sumOf { dir ->
            dir.listFiles()?.sumOf { it.length() } ?: 0L
        }
    }

    fun clearLocalMediaCache(): Long {
        val freed = calculateLocalMediaCacheBytes()
        listOf(
            File(context.cacheDir, "decrypted_media"),
            File(context.cacheDir, "voice_notes")
        ).forEach { dir ->
            dir.listFiles()?.forEach { it.delete() }
        }
        return freed
    }
}
