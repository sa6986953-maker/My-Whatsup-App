package com.example.core

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.util.Log
import com.google.android.gms.auth.api.phone.SmsRetriever
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.common.api.Status
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

private const val TAG = "SmsRetrieverHelper"

/**
 * Listens for incoming SMS verification messages via Google Play Services SMS Retriever API
 * (no READ_SMS permission required) and extracts 6-digit OTP codes automatically.
 */
object SmsRetrieverHelper {

    private val OTP_REGEX = Regex("\\b(\\d{6})\\b")

    fun observeIncomingOtp(context: Context): Flow<String> = callbackFlow {
        val appContext = context.applicationContext
        val client = SmsRetriever.getClient(appContext)
        client.startSmsRetriever()
            .addOnSuccessListener {
                Log.d(TAG, "SMS Retriever started")
            }
            .addOnFailureListener { e ->
                Log.w(TAG, "SMS Retriever unavailable: ${e.message}")
            }

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                if (intent?.action != SmsRetriever.SMS_RETRIEVED_ACTION) return
                val extras = intent.extras ?: return
                @Suppress("DEPRECATION")
                val status = extras.get(SmsRetriever.EXTRA_STATUS) as? Status ?: return
                if (status.statusCode == CommonStatusCodes.SUCCESS) {
                    @Suppress("DEPRECATION")
                    val message = extras.getString(SmsRetriever.EXTRA_SMS_MESSAGE).orEmpty()
                    val match = OTP_REGEX.find(message)
                    if (match != null) {
                        trySend(match.groupValues[1])
                    }
                }
            }
        }

        val filter = IntentFilter(SmsRetriever.SMS_RETRIEVED_ACTION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            appContext.registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            appContext.registerReceiver(receiver, filter)
        }

        awaitClose {
            runCatching { appContext.unregisterReceiver(receiver) }
        }
    }
}
