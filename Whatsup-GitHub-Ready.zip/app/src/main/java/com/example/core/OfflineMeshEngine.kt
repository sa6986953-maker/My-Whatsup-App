package com.example.core

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.p2p.WifiP2pManager
import android.util.Log
import com.example.data.model.NearbyBluetoothPeer
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

private const val TAG = "OfflineMeshEngine"

data class MeshStatus(
    val networkOnline: Boolean = true,
    val offlineModeActive: Boolean = false,
    val autoTriggeredByBle: Boolean = false,
    val bluetoothEnabled: Boolean = false,
    val wifiDirectReady: Boolean = false,
    val scanning: Boolean = false,
    val advertising: Boolean = false,
    val whatsupServiceUuid: String = WhatsupBleScannerService.WHATSUP_MESH_SERVICE_UUID.toString(),
    val pendingSyncCount: Int = 0,
    val nearbyPeers: List<NearbyBluetoothPeer> = emptyList(),
    val statusBanner: String = "Connected to Whatsup Cloud"
)

/**
 * Coordinates Android ConnectivityManager, WifiP2pManager, and [WhatsupBleScannerService]
 * so the app continuously scans for nearby Whatsup Service UUID broadcasters and
 * automatically transitions into Offline Chat Mode when internet drops OR a nearby
 * Whatsup BLE mesh peer is detected.
 */
class OfflineMeshEngine(private val context: Context) {

    private val connectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
    private val wifiP2pManager =
        context.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager

    val bleScannerService = WhatsupBleScannerService(context.applicationContext)

    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _status = MutableStateFlow(MeshStatus())
    val status: StateFlow<MeshStatus> = _status.asStateFlow()

    private var manualOfflineOverride: Boolean? = null
    private var lastNetworkOnline: Boolean = true
    private var lastBleSnapshot: BleScanSnapshot = BleScanSnapshot()

    private val networkCallback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            recomputeMeshState(online = true, bleSnapshot = lastBleSnapshot)
        }

        override fun onLost(network: Network) {
            recomputeMeshState(online = isCurrentlyOnline(), bleSnapshot = lastBleSnapshot)
        }

        override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
            val validated = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            recomputeMeshState(online = validated, bleSnapshot = lastBleSnapshot)
        }
    }

    init {
        lastNetworkOnline = isCurrentlyOnline()
        recomputeMeshState(online = lastNetworkOnline, bleSnapshot = bleScannerService.snapshot.value)

        try {
            connectivityManager?.registerDefaultNetworkCallback(networkCallback)
        } catch (e: Exception) {
            Log.w(TAG, "Unable to register network callback: ${e.message}")
        }

        engineScope.launch {
            bleScannerService.snapshot.collect { snap ->
                lastBleSnapshot = snap
                recomputeMeshState(online = lastNetworkOnline, bleSnapshot = snap)
            }
        }

        // Start continuous Whatsup Service UUID BLE scanning immediately if permissions are already granted
        if (bleScannerService.hasScanPermission() && bleScannerService.isBluetoothEnabled()) {
            bleScannerService.startContinuousScan()
            bleScannerService.startAdvertisingWhatsupService()
        }
    }

    private fun isCurrentlyOnline(): Boolean {
        val cm = connectivityManager ?: return true
        val network = cm.activeNetwork ?: return false
        val caps = cm.getNetworkCapabilities(network) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private fun recomputeMeshState(online: Boolean, bleSnapshot: BleScanSnapshot) {
        lastNetworkOnline = online
        val wifiP2pAvailable = wifiP2pManager != null
        val peerDetected = bleSnapshot.whatsupPeerDetected

        // Automatically trigger Offline Chat Mode when internet is lost OR a Whatsup Service UUID peer is detected nearby
        val offlineActive = manualOfflineOverride ?: (!online || peerDetected)
        val autoBleTriggered = manualOfflineOverride == null && online && peerDetected

        val banner = when {
            !online -> "No Internet • Auto-switched to 100m Bluetooth Mesh"
            autoBleTriggered -> "Whatsup BLE Peer Detected (${bleSnapshot.discoveredPeers.size}) • Auto Offline Chat Active"
            manualOfflineOverride == true -> "Bluetooth Offline Mode Enabled (Manual)"
            bleSnapshot.scanning -> "Scanning Whatsup UUID (${bleSnapshot.serviceUuid.take(8)}...) • Auto-Mesh Ready"
            else -> bleSnapshot.statusDetail
        }

        _status.value = _status.value.copy(
            networkOnline = online,
            offlineModeActive = offlineActive,
            autoTriggeredByBle = autoBleTriggered,
            bluetoothEnabled = bleSnapshot.bluetoothEnabled || bleScannerService.isBluetoothEnabled(),
            wifiDirectReady = wifiP2pAvailable,
            scanning = bleSnapshot.scanning,
            advertising = bleSnapshot.advertising,
            whatsupServiceUuid = bleSnapshot.serviceUuid,
            nearbyPeers = bleSnapshot.discoveredPeers,
            statusBanner = banner
        )
    }

    fun setManualOfflineMode(enabled: Boolean) {
        manualOfflineOverride = if (enabled) true else null
        if (enabled && bleScannerService.isBluetoothEnabled()) {
            bleScannerService.startAdvertisingWhatsupService()
            if (bleScannerService.hasScanPermission()) {
                bleScannerService.startContinuousScan()
            }
        }
        recomputeMeshState(isCurrentlyOnline(), lastBleSnapshot)
    }

    fun updatePendingSyncCount(count: Int) {
        _status.value = _status.value.copy(pendingSyncCount = count)
    }

    fun hasBluetoothPermissions(): Boolean = bleScannerService.hasScanPermission()

    fun startNearbyScan() {
        bleScannerService.startContinuousScan()
        if (bleScannerService.isBluetoothEnabled()) {
            bleScannerService.startAdvertisingWhatsupService()
        }
        recomputeMeshState(isCurrentlyOnline(), bleScannerService.snapshot.value)
    }

    fun stopScan() {
        bleScannerService.stopScan()
        recomputeMeshState(isCurrentlyOnline(), bleScannerService.snapshot.value)
    }

    fun togglePeerConnection(peerId: String) {
        bleScannerService.togglePeerConnected(peerId)
    }

    fun release() {
        bleScannerService.release()
        engineScope.cancel()
        try {
            connectivityManager?.unregisterNetworkCallback(networkCallback)
        } catch (_: Exception) {
        }
    }
}
