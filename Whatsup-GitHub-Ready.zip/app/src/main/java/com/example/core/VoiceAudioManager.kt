package com.example.core

import android.content.Context
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

private const val TAG = "VoiceAudioManager"

data class VoiceRecordingState(
    val isRecording: Boolean = false,
    val elapsedSeconds: Int = 0,
    val outputFile: File? = null
)

data class VoicePlaybackState(
    val playingMessageId: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Int = 0,
    val durationMs: Int = 0
)

class VoiceAudioManager(private val context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var recorder: MediaRecorder? = null
    private var player: MediaPlayer? = null
    private var recordTimerJob: Job? = null
    private var playbackProgressJob: Job? = null
    private var currentOutputFile: File? = null

    private val _recordingState = MutableStateFlow(VoiceRecordingState())
    val recordingState: StateFlow<VoiceRecordingState> = _recordingState.asStateFlow()

    private val _playbackState = MutableStateFlow(VoicePlaybackState())
    val playbackState: StateFlow<VoicePlaybackState> = _playbackState.asStateFlow()

    fun startRecording(): Boolean {
        stopRecording(discard = true)
        val dir = File(context.cacheDir, "voice_notes").apply { mkdirs() }
        val file = File(dir, "voice_${UUID.randomUUID()}.m4a")
        return try {
            val rec = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(context)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }
            rec.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioEncodingBitRate(64_000)
                setAudioSamplingRate(32_000)
                setOutputFile(file.absolutePath)
                prepare()
                start()
            }
            recorder = rec
            currentOutputFile = file
            _recordingState.value = VoiceRecordingState(isRecording = true, elapsedSeconds = 0, outputFile = file)
            recordTimerJob?.cancel()
            recordTimerJob = scope.launch {
                while (isActive) {
                    delay(1000L)
                    _recordingState.value = _recordingState.value.copy(
                        elapsedSeconds = _recordingState.value.elapsedSeconds + 1
                    )
                }
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start audio recording", e)
            runCatching { file.delete() }
            recorder = null
            currentOutputFile = null
            _recordingState.value = VoiceRecordingState()
            false
        }
    }

    fun stopRecording(discard: Boolean = false): Pair<File?, Int> {
        recordTimerJob?.cancel()
        recordTimerJob = null
        val durationSec = _recordingState.value.elapsedSeconds.coerceAtLeast(1)
        val file = currentOutputFile
        try {
            recorder?.apply {
                stop()
                release()
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping MediaRecorder: ${e.message}")
            runCatching { recorder?.release() }
        }
        recorder = null
        currentOutputFile = null
        _recordingState.value = VoiceRecordingState()

        if (discard || file == null || !file.exists() || file.length() == 0L) {
            runCatching { file?.delete() }
            return null to 0
        }
        return file to durationSec
    }

    fun playOrToggle(messageId: String, audioFile: File, onError: (String) -> Unit = {}) {
        val current = _playbackState.value
        if (current.playingMessageId == messageId && player != null) {
            if (current.isPlaying) {
                player?.pause()
                playbackProgressJob?.cancel()
                _playbackState.value = current.copy(isPlaying = false)
            } else {
                player?.start()
                startPlaybackTracker(messageId)
            }
            return
        }

        stopPlayback()
        if (!audioFile.exists() || audioFile.length() == 0L) {
            onError("Voice file is not downloaded yet.")
            return
        }

        try {
            val mp = MediaPlayer().apply {
                setDataSource(audioFile.absolutePath)
                prepare()
                setOnCompletionListener {
                    stopPlayback()
                }
                start()
            }
            player = mp
            _playbackState.value = VoicePlaybackState(
                playingMessageId = messageId,
                isPlaying = true,
                positionMs = 0,
                durationMs = mp.duration.coerceAtLeast(1)
            )
            startPlaybackTracker(messageId)
        } catch (e: Exception) {
            Log.e(TAG, "Audio playback failed", e)
            stopPlayback()
            onError(e.localizedMessage ?: "Unable to play voice message")
        }
    }

    private fun startPlaybackTracker(messageId: String) {
        playbackProgressJob?.cancel()
        playbackProgressJob = scope.launch {
            while (isActive) {
                val mp = player ?: break
                if (!mp.isPlaying) break
                _playbackState.value = VoicePlaybackState(
                    playingMessageId = messageId,
                    isPlaying = true,
                    positionMs = mp.currentPosition,
                    durationMs = mp.duration.coerceAtLeast(1)
                )
                delay(200L)
            }
        }
    }

    fun stopPlayback() {
        playbackProgressJob?.cancel()
        playbackProgressJob = null
        runCatching {
            player?.stop()
        }
        runCatching {
            player?.release()
        }
        player = null
        _playbackState.value = VoicePlaybackState()
    }

    fun release() {
        stopRecording(discard = true)
        stopPlayback()
        scope.cancel()
    }

    companion object {
        fun formatDuration(seconds: Int): String {
            val m = seconds / 60
            val s = seconds % 60
            return "%d:%02d".format(m, s)
        }
    }
}
