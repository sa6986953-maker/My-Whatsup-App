package com.example.core

import com.google.i18n.phonenumbers.NumberParseException
import com.google.i18n.phonenumbers.PhoneNumberUtil
import java.security.MessageDigest

data class CountryDialCode(
    val isoCode: String,
    val name: String,
    val dialCode: String,
    val flagEmoji: String,
    val exampleHint: String
)

object PhoneNumberUtils {

    private val phoneUtil: PhoneNumberUtil = PhoneNumberUtil.getInstance()

    val supportedCountries: List<CountryDialCode> = listOf(
        CountryDialCode("PK", "Pakistan", "+92", "🇵🇰", "300 4512980"),
        CountryDialCode("US", "United States", "+1", "🇺🇸", "415 555 0142"),
        CountryDialCode("GB", "United Kingdom", "+44", "🇬🇧", "7700 900123"),
        CountryDialCode("AE", "United Arab Emirates", "+971", "🇦🇪", "50 123 4567"),
        CountryDialCode("SA", "Saudi Arabia", "+966", "🇸🇦", "50 123 4567"),
        CountryDialCode("IN", "India", "+91", "🇮🇳", "98765 43210"),
        CountryDialCode("CA", "Canada", "+1", "🇨🇦", "604 555 0199"),
        CountryDialCode("DE", "Germany", "+49", "🇩🇪", "151 23456789"),
        CountryDialCode("TR", "Turkey", "+90", "🇹🇷", "532 123 4567"),
        CountryDialCode("MY", "Malaysia", "+60", "🇲🇾", "12 345 6789"),
        CountryDialCode("QA", "Qatar", "+974", "🇶🇦", "3312 3456"),
        CountryDialCode("AU", "Australia", "+61", "🇦🇺", "412 345 678")
    )

    val defaultCountry: CountryDialCode = supportedCountries.first()

    /**
     * Normalizes user input + selected country dial code into strict E.164 format (e.g. "+923004512980").
     * Returns null if the number is structurally invalid or impossible.
     */
    fun normalizeToE164(
        rawInput: String,
        defaultRegionIso: String = "PK",
        dialCodePrefix: String = "+92"
    ): String? {
        val cleaned = rawInput.trim()
        if (cleaned.isEmpty()) return null
        val candidate = if (cleaned.startsWith("+")) {
            cleaned
        } else {
            val digitsOnly = cleaned.filter { it.isDigit() }
            if (digitsOnly.isEmpty()) return null
            val strippedLeadingZero = if (defaultRegionIso == "PK" && digitsOnly.startsWith("0")) {
                digitsOnly.drop(1)
            } else {
                digitsOnly
            }
            "$dialCodePrefix$strippedLeadingZero"
        }

        return try {
            val parsed = phoneUtil.parse(candidate, defaultRegionIso)
            if (!phoneUtil.isPossibleNumber(parsed) || !phoneUtil.isValidNumber(parsed)) {
                null
            } else {
                phoneUtil.format(parsed, PhoneNumberUtil.PhoneNumberFormat.E164)
            }
        } catch (_: NumberParseException) {
            null
        }
    }

    fun formatDisplay(e164: String): String {
        return try {
            val parsed = phoneUtil.parse(e164, "PK")
            phoneUtil.format(parsed, PhoneNumberUtil.PhoneNumberFormat.INTERNATIONAL)
        } catch (_: Exception) {
            e164
        }
    }

    /**
     * Deterministic lowercase SHA-256 hex digest of an E.164 phone number for
     * privacy-preserving contact discovery in `/phoneDirectory/{phoneHash}`.
     */
    fun hashPhoneE164(e164: String): String {
        val canonical = e164.trim()
        val digest = MessageDigest.getInstance("SHA-256")
            .digest(canonical.toByteArray(Charsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }
    }
}
