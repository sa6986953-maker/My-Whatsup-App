package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.ChatMessage
import com.example.data.repository.LocalWhatsupStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LocalWhatsupStoreTest {

    @Test
    fun offlineBluetoothOutboxIsUidScopedAndPersistsAcrossRestarts() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val store = LocalWhatsupStore(context)
        store.clearUserOutbox("uid_alice")
        store.clearUserOutbox("uid_bob")

        val msgAlice1 = ChatMessage(
            id = "bt_1",
            userId = "uid_alice",
            chatId = "conv_1",
            senderName = "Alice",
            senderPhone = "+923001112233",
            fromMe = true,
            text = "Salam via Bluetooth Mesh",
            messageType = "TEXT",
            tickStatus = "PENDING_SYNC",
            viaBluetooth = true,
            timeLabel = "10:15 AM"
        )
        val msgAlice2 = msgAlice1.copy(id = "bt_2", text = "Follow up mesh packet")

        store.enqueueOfflineMessage("uid_alice", "conv_1", msgAlice1)
        store.enqueueOfflineMessage("uid_alice", "conv_1", msgAlice2)

        assertEquals(2, store.observeAllPendingCount("uid_alice").first())
        // Zero cross-UID leakage
        assertEquals(0, store.observeAllPendingCount("uid_bob").first())
        assertTrue(store.getPendingOutboxForUser("uid_bob").isEmpty())

        // Verify disk persistence across a fresh LocalWhatsupStore instance
        val reloadedStore = LocalWhatsupStore(context)
        val reloadedMessages = reloadedStore.observeQueuedMessages("uid_alice", "conv_1").first()
        assertEquals(listOf("bt_1", "bt_2"), reloadedMessages.map { it.id })
        assertEquals("Salam via Bluetooth Mesh", reloadedMessages.first().text)

        // Remove one synced message and verify remainder stays queued
        reloadedStore.removeSyncedMessages("uid_alice", "conv_1", setOf("bt_1"))
        val remaining = reloadedStore.getPendingOutboxForUser("uid_alice")["conv_1"].orEmpty()
        assertEquals(listOf("bt_2"), remaining.map { it.id })
        assertEquals(1, reloadedStore.observeAllPendingCount("uid_alice").first())

        reloadedStore.clearUserOutbox("uid_alice")
    }
}
