package com.example

import com.example.core.PhoneNumberUtils
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNull
import org.junit.Test

class PhoneNumberUtilsTest {

    @Test
    fun normalizeToE164_handlesPakistanDefaultAndInternationalNumbers() {
        assertEquals(
            "+923004512980",
            PhoneNumberUtils.normalizeToE164("0300 4512980", "PK", "+92")
        )
        assertEquals(
            "+923004512980",
            PhoneNumberUtils.normalizeToE164("3004512980", "PK", "+92")
        )
        assertEquals(
            "+14155550142",
            PhoneNumberUtils.normalizeToE164("415-555-0142", "US", "+1")
        )
        assertEquals(
            "+447911123456",
            PhoneNumberUtils.normalizeToE164("+44 7911 123456", "GB", "+44")
        )
    }

    @Test
    fun normalizeToE164_rejectsInvalidOrEmptyNumbers() {
        assertNull(PhoneNumberUtils.normalizeToE164("", "PK", "+92"))
        assertNull(PhoneNumberUtils.normalizeToE164("123", "PK", "+92"))
        assertNull(PhoneNumberUtils.normalizeToE164("abc-xyz", "PK", "+92"))
    }

    @Test
    fun hashPhoneE164_isDeterministic64CharHex() {
        val h1 = PhoneNumberUtils.hashPhoneE164("+923004512980")
        val h2 = PhoneNumberUtils.hashPhoneE164(" +923004512980 ")
        val hOther = PhoneNumberUtils.hashPhoneE164("+923004512981")

        assertEquals(64, h1.length)
        assertEquals(h1, h2)
        assertNotEquals(h1, hOther)
    }
}
