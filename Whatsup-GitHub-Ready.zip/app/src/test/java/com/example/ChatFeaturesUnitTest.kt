package com.example

import com.example.data.model.ChatMessage
import com.example.data.model.MessageReactionHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ChatFeaturesUnitTest {

    @Test
    fun computeToggledReactions_addsSwitchesAndRemovesCorrectly() {
        // Initial reaction added
        val (afterAdd, myAfterAdd) = MessageReactionHelper.computeToggledReactions(
            currentReactions = emptyMap(),
            currentMyReaction = "",
            emoji = "❤️"
        )
        assertEquals(mapOf("❤️" to 1L), afterAdd)
        assertEquals("❤️", myAfterAdd)

        // Switching to a different emoji decrements old and increments new
        val (afterSwitch, myAfterSwitch) = MessageReactionHelper.computeToggledReactions(
            currentReactions = mapOf("❤️" to 2L, "👍" to 1L),
            currentMyReaction = "❤️",
            emoji = "👍"
        )
        assertEquals(mapOf("❤️" to 1L, "👍" to 2L), afterSwitch)
        assertEquals("👍", myAfterSwitch)

        // Tapping the same emoji toggles it off and removes 0-count key
        val (afterRemove, myAfterRemove) = MessageReactionHelper.computeToggledReactions(
            currentReactions = mapOf("👍" to 1L),
            currentMyReaction = "👍",
            emoji = "👍"
        )
        assertTrue(afterRemove.isEmpty())
        assertEquals("", myAfterRemove)
    }

    @Test
    fun messageKeywordFilter_matchesTextSenderOrMediaMeta() {
        val msgs = listOf(
            ChatMessage(id = "1", senderName = "Ammi", text = "Khana kha liya beta?", fromMe = false),
            ChatMessage(id = "2", senderName = "Me", text = "Ji Ammi, Lahore pahunch gaya", fromMe = true),
            ChatMessage(id = "3", senderName = "Bilal", text = "Check attached bill", mediaMeta = "Electricity_Bill.pdf", fromMe = false),
            ChatMessage(id = "4", senderName = "Bilal", text = "Hidden deleted", deletedForMe = true, fromMe = false)
        )

        val query = "lahore"
        val filtered = msgs
            .filter { !it.deletedForMe }
            .filter {
                it.text.contains(query, ignoreCase = true) ||
                    it.senderName.contains(query, ignoreCase = true) ||
                    (it.mediaMeta?.contains(query, ignoreCase = true) == true)
            }
        assertEquals(listOf("2"), filtered.map { it.id })

        val pdfMatches = msgs
            .filter { !it.deletedForMe }
            .filter {
                it.text.contains("Electricity", ignoreCase = true) ||
                    (it.mediaMeta?.contains("Electricity", ignoreCase = true) == true)
            }
        assertEquals(listOf("3"), pdfMatches.map { it.id })
        assertFalse(msgs.filter { !it.deletedForMe }.any { it.id == "4" })
    }
}
