package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.core.CallSignalQuality
import com.example.core.NetworkLatencyMonitor
import com.example.core.OfflineMeshEngine
import com.example.core.WhatsupBleScannerService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class CallAndMeshServiceTest {

    @Test
    fun `latency thresholds map to green yellow red signal qualities`() {
        assertEquals(CallSignalQuality.GOOD, NetworkLatencyMonitor.classifyLatency(24))
        assertEquals(CallSignalQuality.GOOD, NetworkLatencyMonitor.classifyLatency(120))
        assertEquals(CallSignalQuality.FAIR, NetworkLatencyMonitor.classifyLatency(121))
        assertEquals(CallSignalQuality.FAIR, NetworkLatencyMonitor.classifyLatency(300))
        assertEquals(CallSignalQuality.POOR, NetworkLatencyMonitor.classifyLatency(301))
        assertEquals(CallSignalQuality.POOR, NetworkLatencyMonitor.classifyLatency(null))
    }

    @Test
    fun `ble scanner service and mesh engine initialize with canonical whatsup uuid`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val bleService = WhatsupBleScannerService(context)
        assertEquals(
            "a7e30001-5748-4154-5355-504d45534801",
            bleService.snapshot.value.serviceUuid
        )
        val mesh = OfflineMeshEngine(context)
        assertEquals(
            WhatsupBleScannerService.WHATSUP_MESH_SERVICE_UUID.toString(),
            mesh.status.value.whatsupServiceUuid
        )
        assertFalse(mesh.status.value.scanning)
        mesh.release()
        bleService.release()
    }
}
